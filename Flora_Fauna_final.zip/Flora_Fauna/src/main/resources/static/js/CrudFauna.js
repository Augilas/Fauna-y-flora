let productos = [];

function Salir() {
    var fechaActual = new Date();

    fechaActual.setDate(fechaActual.getDate() - 1);

    var fechaExpiracion = fechaActual.toUTCString();

    document.cookie = "token=; expires=" + fechaExpiracion + "; path=/";
    document.cookie = "user=; expires=" + fechaExpiracion + "; path=/";
    location.reload()
}

function ObtenerFloraFauna() {
    let tipo = 1
    fetch('/florafauna/all?id=' + tipo, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    }).then(res => {
        res.json().then(json => {
            productos = json;
            ImprimirProductos();
        });
    });
}

function ImprimirProductos() {
    let contenedor = document.getElementById("cuerpoTabla");
    contenedor.innerHTML = "";

    productos.forEach(producto => {
        contenedor.innerHTML += MapearProducto(producto);
    });
}

function MapearProducto(producto) {
    return `<tr>
    <td>
        <button class="border rounded-full bg-[#dfe7a3] w-20 h-8" onclick="EliminarFloraFauna('${producto.cod}')">Eliminar</button>
        <button class="border rounded-full text-white bg-[#6ea1a3] w-20 h-8" onclick="PopularDatosCampos('${producto.cod}')">Actualizar</button>
      </td>
    <td>${producto.cod}</td>
    <td>${producto.nombre}</td>
    <td>${producto.nombrecientifico}</td>
    <td><img src='data:image/png;base64,${producto.imagen}' width='100px'></img></td>
    <td>${producto.fecha}</td>
    <td>${producto.descripcion}</td>
  </tr>`;
}

function EliminarFloraFauna(id) {
    let valor = id.split("-")
    fetch('florafauna?cod=' + id + '&tipo=' + valor[0], { method: "Delete" }).then(res => {
        ObtenerFloraFauna();
    });
}

function PopularDatosCampos(cod) {
    let producto = productos.filter(p => p.cod === cod)[0];

    document.getElementById('comun_n').value = producto.nombre;
    document.getElementById('cientifico_n').value = producto.nombrecientifico;
    document.getElementById('cod_f').value = producto.cod;
    document.getElementById('fecha_primer').value = producto.fecha;
    document.getElementById('descipcion_n').value = producto.descripcion;
}

function ActualizarProducto() {
    const fileInput = document.getElementById('imagen_n');
    const file = fileInput.files[0];
    const reader = new FileReader();
    let valor = document.getElementById("cod_f").value.split("-")
    if (file) {
        reader.onload = function (event) {
            const base64String = event.target.result.split(',')[1];
            let nombre = document.getElementById("comun_n").value
            let nombrecientifico = document.getElementById("cientifico_n").value
            let cod = document.getElementById("cod_f").value
            let imagen = base64String
            let fecha = document.getElementById("fecha_primer").value
            let descripcion = document.getElementById("descipcion_n").value
            fetch("/florafauna?tipo=" + valor[0], {
                method: "PUT",
                body: JSON.stringify({ nombre, nombrecientifico, cod, fecha, descripcion, imagen }),
                headers: {
                    "Content-type": 'application/json; charset=UTF-8'
                }
            }).then(res => {
                ObtenerFloraFauna();
            });
        }
        reader.readAsDataURL(file);
    } else {
        let nombre = document.getElementById("comun_n").value;
        let nombrecientifico = document.getElementById("cientifico_n").value;
        let cod = document.getElementById("cod_f").value;
        let fecha = document.getElementById("fecha_primer").value
        let descripcion = document.getElementById("descipcion_n").value;
        fetch("/florafauna?tipo=" + valor[0], {
            method: "PUT",
            body: JSON.stringify({ nombre, nombrecientifico, cod, fecha, descripcion }),
            headers: {
                "Content-type": 'application/json; charset=UTF-8'
            }
        }).then(res => {
            ObtenerFloraFauna();
        });
    }
}