let productos = [];

function Salir() {
    var fechaActual = new Date();

    fechaActual.setDate(fechaActual.getDate() - 1);

    var fechaExpiracion = fechaActual.toUTCString();

    document.cookie = "token=; expires=" + fechaExpiracion + "; path=/";
    document.cookie = "user=; expires=" + fechaExpiracion + "; path=/";
    location.reload()
}

function ObtenerFloraFauna() {
    fetch('/crud/tipousuario', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    }).then(res => {
        res.json().then(json => {
            productos = json;
            ImprimirProductos();
        });
    });
}

function ImprimirProductos() {
    let contenedor = document.getElementById("cuerpoTabla");
    contenedor.innerHTML = "";

    productos.forEach(producto => {
        contenedor.innerHTML += MapearProducto(producto);
    });
}

function MapearProducto(producto) {
    return `<tr>
    <td>
        <button class="border rounded-full bg-[#dfe7a3] w-20 h-8" onclick="EliminarFloraFauna('${producto.cod}')">Eliminar</button>
        <button class="border rounded-full text-white bg-[#6ea1a3] w-20 h-8" onclick="PopularDatosCampos('${producto.cod}')">Actualizar</button>
      </td>
    <td>${producto.cod}</td>
    <td>${producto.tipo}</td>
  </tr>`;
}

function EliminarFloraFauna(id) {
    fetch('/crud/tipousuario?id=' + id, { method: "Delete" }).then(res => {
        ObtenerFloraFauna();
    });
}


function PopularDatosCampos(cod) {
    let producto = productos.filter(p => p.cod === cod)[0];

    document.getElementById('codi').value = producto.cod;
    document.getElementById('nombre').value = producto.tipo;

}

function ActualizarProducto() {
    let cod = document.getElementById("codi").value;
    let tipo = document.getElementById("nombre").value;
    fetch("/crud/tipousuario", {
        method: "PUT",
        body: JSON.stringify({ cod, tipo }),
        headers: {
            "Content-type": 'application/json; charset=UTF-8'
        }
    }).then(res => {
        ObtenerFloraFauna();
    });
}

function mostrarInput() {
    Swal.fire({
        title: 'Ingresa tus datos',
        html:
            '<input id="swal-input1" class="swal2-input" placeholder="Codigo">' +
            '<input id="swal-input2" class="swal2-input" placeholder="Nombre">',
        showCancelButton: true,
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar',
        showLoaderOnConfirm: true,
        preConfirm: () => {
            const cod = document.getElementById('swal-input1').value;
            const nombre = document.getElementById('swal-input2').value;

            return fetch('/crud/tipousuario?cod='+cod + '&nombre='+nombre, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Hubo un problema al enviar los datos.');
                }
                return response.json();
            })
            .catch(error => {
                Swal.showValidationMessage(
                    `Error: ${error}`
                );
            });
        },
        allowOutsideClick: () => !Swal.isLoading()
    }).then((result) => {
        if (result.value == 1) {
            Swal.fire(
                'Datos enviados!',
                'Los datos han sido enviados exitosamente.',
                'success'
            ).then(() => {
                location.reload();
            });
        } else if(result.value == 0) {
            Swal.fire(
                'Datos no enviados!',
                'Los datos no se han podido procesar.',
                'error'
            );
        } else {
            
        }
    });
}