let productos = [];

function Salir() {
    var fechaActual = new Date();

    fechaActual.setDate(fechaActual.getDate() - 1);

    var fechaExpiracion = fechaActual.toUTCString();

    document.cookie = "token=; expires=" + fechaExpiracion + "; path=/";
    document.cookie = "user=; expires=" + fechaExpiracion + "; path=/";
    location.reload()
}

function ObtenerFloraFauna() {
    fetch('/crud/usuario', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    }).then(res => {
        res.json().then(json => {
            console.log(json)
            productos = json;
            ImprimirProductos();
        });
    });
}

function ImprimirProductos() {
    let contenedor = document.getElementById("cuerpoTabla");
    contenedor.innerHTML = "";

    productos.forEach(producto => {
        contenedor.innerHTML += MapearProducto(producto);
    });
}

function MapearProducto(producto) {
    return `<tr>
    <td>
        <button class="border rounded-full bg-[#dfe7a3] w-20 h-8" onclick="EliminarFloraFauna('${producto.cod}')">Eliminar</button>
        <button class="border rounded-full text-white bg-[#6ea1a3] w-20 h-8" onclick="PopularDatosCampos('${producto.cod}')">Actualizar</button>
      </td>
    <td>${producto.cod}</td>
    <td>${producto.usuario}</td>
    <td>${producto.contrasena}</td>
    <td>${producto.fecha}</td>
    <td>${producto.cedulabiologo}</td>
    <td>${producto.cedulaadmin}</td>
    <td>${producto.cedulaestudiante}</td>
    <td>${producto.codtipo}</td>
  </tr>`;
}

function EliminarFloraFauna(id) {
    fetch('/crud/usuario?cod=' + id, { method: "Delete" }).then(res => {
        ObtenerFloraFauna();
    });
}


function PopularDatosCampos(cod) {
    let producto = productos.filter(p => p.cod === cod)[0];
    console.log(producto)
    document.getElementById('cod').value = producto.cod;
    document.getElementById('usuario').value = producto.usuario;
    document.getElementById('fecha').value = producto.fecha;
    document.getElementById('cedulabiologo').value = producto.cedulabiologo;
    document.getElementById('cedulaadmin').value = producto.cedulaadmin;
    document.getElementById('cedulaestudiante').value = producto.cedulaestudiante;
    document.getElementById('tipo_usuario').value = producto.codtipo;
    document.getElementById('contrasena').value = producto.contrasena;

}

function ActualizarProducto() {
    let data
    let cedulabiologo = document.getElementById('cedulabiologo').value
    let cedulaestudiante = document.getElementById('cedulaestudiante').value
    let cedulaadmin = document.getElementById('cedulaadmin').value
    if (cedulaadmin == "" && cedulaestudiante == "") {
        data = {
            cod: document.getElementById('cod').value,
            usuario: document.getElementById('usuario').value,
            contrasena: document.getElementById('contrasena').value,
            codtipo: document.getElementById('tipo_usuario').value,
            cedulabiologo: document.getElementById('cedulabiologo').value
        }
    } else if (cedulabiologo == "" && cedulaestudiante == "") {
        data = {
            cod: document.getElementById('cod').value,
            usuario: document.getElementById('usuario').value,
            contrasena: document.getElementById('contrasena').value,
            codtipo: document.getElementById('tipo_usuario').value,
            cedulaadmin: document.getElementById('cedulaadmin').value
        }
    } else if (cedulabiologo == "" && cedulaadmin == "") {
        data = {
            cod: document.getElementById('cod').value,
            usuario: document.getElementById('usuario').value,
            contrasena: document.getElementById('contrasena').value,
            codtipo: document.getElementById('tipo_usuario').value,
            cedulaestudiante: document.getElementById('cedulaestudiante').value
        }
    } else {
        Swal.fire(
            'Datos no enviados!',
            'Ingrese solamente 1 cedula',
            'error'
        );
    }
    fetch("/crud/usuario", {
        method: "PUT",
        body: JSON.stringify(data),
        headers: {
            "Content-type": 'application/json; charset=UTF-8'
        }
    }).then(res => {
        ObtenerFloraFauna();
    });
}

function mostrarInput() {
    Swal.fire({
        title: 'Ingresa tus datos',
        html:
            '<input id="swal-input1" class="swal2-input" placeholder="Usuario">' +
            '<input id="swal-input2" class="swal2-input" type="password" placeholder="Contrasena">' +
            '<h2>Rellene la cédula correspondiente (solamente una)</h2>' +
            '<select id="cedula" class="swal2-select">' +
            '<option value="1">Cedula Biologo</option>' +
            '<option value="2">Cedula Admin</option>' +
            '<option value="3">Cedula Estudiante</option>' +
            '</select>' +
            '<input id="swal-input3" class="swal2-input" placeholder="Cedula">' +
            '<input id="swal-input4" class="swal2-input" placeholder="Tipo Usuario">',
        showCancelButton: true,
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar',
        showLoaderOnConfirm: true,
        preConfirm: () => {
            let data
            const cedulaSeleccionada = document.getElementById('cedula').value
            if (cedulaSeleccionada == '1') {
                data = {
                    usuario: document.getElementById('swal-input1').value,
                    contrasena: document.getElementById('swal-input2').value,
                    codtipo: document.getElementById('swal-input4').value,
                    cedulabiologo: document.getElementById('swal-input3').value
                }
            } else if (cedulaSeleccionada == '2') {
                data = {
                    usuario: document.getElementById('swal-input1').value,
                    contrasena: document.getElementById('swal-input2').value,
                    codtipo: document.getElementById('swal-input4').value,
                    cedulaadmin: document.getElementById('swal-input3').value
                }
            } else {
                data = {
                    usuario: document.getElementById('swal-input1').value,
                    contrasena: document.getElementById('swal-input2').value,
                    codtipo: document.getElementById('swal-input4').value,
                    cedulaestudiante: document.getElementById('swal-input3').value
                }
            }
            return fetch('/crud/usuario', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Hubo un problema al enviar los datos.');
                    }
                    return response.json();
                })
                .catch(error => {
                    Swal.showValidationMessage(
                        `Error: ${error}`
                    );
                });
        },
        allowOutsideClick: () => !Swal.isLoading()
    }).then((result) => {
        if (result.value == 1) {
            Swal.fire(
                'Datos enviados!',
                'Los datos han sido enviados exitosamente.',
                'success'
            ).then(() => {
                ObtenerFloraFauna()
            });
        } else if (result.value == 0) {
            Swal.fire(
                'Datos no enviados!',
                'Los datos no se han podido procesar.',
                'error'
            );
        } else {

        }
    });
}

