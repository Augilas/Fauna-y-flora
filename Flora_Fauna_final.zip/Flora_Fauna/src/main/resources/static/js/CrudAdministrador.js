let productos = [];

function Salir() {
    var fechaActual = new Date();

    fechaActual.setDate(fechaActual.getDate() - 1);

    var fechaExpiracion = fechaActual.toUTCString();

    document.cookie = "token=; expires=" + fechaExpiracion + "; path=/";
    document.cookie = "user=; expires=" + fechaExpiracion + "; path=/";
    location.reload()
}

function ObtenerFloraFauna() {
    fetch('/crud/admin', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    }).then(res => {
        res.json().then(json => {
            productos = json;
            ImprimirProductos();
        });
    });
}

function ImprimirProductos() {
    let contenedor = document.getElementById("cuerpoTabla");
    contenedor.innerHTML = "";

    productos.forEach(producto => {
        contenedor.innerHTML += MapearProducto(producto);
    });
}

function MapearProducto(producto) {
    return `<tr>
    <td>
        <button class="border rounded-full bg-[#dfe7a3] w-20 h-8" onclick="EliminarFloraFauna('${producto.cedula}')">Eliminar</button>
        <button class="border rounded-full text-white bg-[#6ea1a3] w-20 h-8" onclick="PopularDatosCampos('${producto.cedula}')">Actualizar</button>
      </td>
    <td>${producto.cedula}</td>
    <td>${producto.nombre}</td>
    <td>${producto.apellido}</td>
    <td>${producto.correo}</td>
    <td>${producto.codtipo}</td>
  </tr>`;
}

function EliminarFloraFauna(id) {
    fetch('/crud/admin?cedula=' + id, { method: "Delete" }).then(res => {
        ObtenerFloraFauna();
    });
}


function PopularDatosCampos(cod) {
    let producto = productos.filter(p => p.cedula === cod)[0];
    document.getElementById('nombre').value = producto.nombre;
    document.getElementById('apellido').value = producto.apellido;
    document.getElementById('correo').value = producto.correo;
    document.getElementById('cedula').value = producto.cedula;
    document.getElementById('tipo').value = producto.codtipo;
}

function ActualizarProducto() {
    const nombre = document.getElementById('nombre').value
    const apellido = document.getElementById('apellido').value
    const correo = document.getElementById('correo').value
    const cedula = document.getElementById('cedula').value
    const codtipo = parseInt(document.getElementById('tipo').value)
    fetch("/crud/admin", {
        method: "PUT",
        headers: {
            "Content-type": 'application/json; charset=UTF-8'
        },
        body: JSON.stringify({ nombre, apellido, correo, cedula, codtipo })
    }).then(res => {
        ObtenerFloraFauna();
    });
}

function mostrarInput() {
    Swal.fire({
        title: 'Ingresa tus datos',
        html:
            '<input id="swal-input1" class="swal2-input" placeholder="Nombre">' +
            '<input id="swal-input2" class="swal2-input" placeholder="Apellido">' +
            '<input id="swal-input3" class="swal2-input" type="email" placeholder="Correo">' +
            '<input id="swal-input4" class="swal2-input" placeholder="Cedula">' +
            '<input id="swal-input5" class="swal2-input" placeholder="Tipo de Usuario">',
        showCancelButton: true,
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar',
        showLoaderOnConfirm: true,
        preConfirm: () => {
            const nombre = document.getElementById('swal-input1').value;
            const apellido = document.getElementById('swal-input2').value;
            const correo = document.getElementById('swal-input3').value;
            const cedula = document.getElementById('swal-input4').value;
            const codtipo = document.getElementById('swal-input5').value;

            return fetch('/crud/admin', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ nombre, apellido, correo, cedula, codtipo })
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Hubo un problema al enviar los datos.');
                    }
                    return response.json();
                })
                .catch(error => {
                    Swal.showValidationMessage(
                        `Error: ${error}`
                    );
                });
        },
        allowOutsideClick: () => !Swal.isLoading()
    }).then((result) => {
        if (result.value == 1) {
            Swal.fire(
                'Datos enviados!',
                'Los datos han sido enviados exitosamente.',
                'success'
            ).then(() => {
                ObtenerFloraFauna()
            });
        } else if (result.value == 0) {
            Swal.fire(
                'Datos no enviados!',
                'Los datos no se han podido procesar.',
                'error'
            );
        } else {

        }
    });
}