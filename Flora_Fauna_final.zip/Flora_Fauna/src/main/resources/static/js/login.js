document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('loginBtn').addEventListener('click', enviarFormulario);
});

function Salir() {
    var fechaActual = new Date();

    fechaActual.setDate(fechaActual.getDate() - 1);

    var fechaExpiracion = fechaActual.toUTCString();

    document.cookie = "token=; expires=" + fechaExpiracion + "; path=/";
    document.cookie = "user=; expires=" + fechaExpiracion + "; path=/";
    location.reload()
}

function enviarFormulario() {
    const username = document.getElementById('usuario').value;
    const password = document.getElementById('contrasena').value;

    fetch('/auth/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, password })
    })
        .then(res => {
            if (res.ok) {
                return res.text();
            } else {
                openModalERROR()
            }
        })
        .then(data => {
            if (data == 'Usuario') {
                var fechaExpiracion = new Date();
                fechaExpiracion.setTime(fechaExpiracion.getTime() + (30 * 60 * 1000)); 
                var expiracion = "expires=" + fechaExpiracion.toUTCString();
                document.cookie = "user=Usuario" + ";" + expiracion + ";path=/";
                window.location.href = "/";
            } else if (data == 'Biologo') {
                var fechaExpiracion = new Date();
                fechaExpiracion.setTime(fechaExpiracion.getTime() + (30 * 60 * 1000)); 
                var expiracion = "expires=" + fechaExpiracion.toUTCString();
                document.cookie = "user=Biologo" + ";" + expiracion + ";path=/";
                window.location.href = "/";
            } else if (data == 'Administrador') {
                var fechaExpiracion = new Date();
                fechaExpiracion.setTime(fechaExpiracion.getTime() + (30 * 60 * 1000)); 
                var expiracion = "expires=" + fechaExpiracion.toUTCString();
                document.cookie = "user=Admin" + ";" + expiracion + ";path=/";
                window.location.href = "/";
            } else {
                openModalERROR()
            }
        })
        .catch(error => {
            console.error('Error de red', error);
        });
}

function openModalERROR() {
    document.getElementById('NosuccessModal').classList.remove('hidden');
}

function closeModalERROR() {
    document.getElementById('NosuccessModal').classList.add('hidden');
}