let productos = [];

function Salir() {
    var fechaActual = new Date();

    fechaActual.setDate(fechaActual.getDate() - 1);

    var fechaExpiracion = fechaActual.toUTCString();

    document.cookie = "token=; expires=" + fechaExpiracion + "; path=/";
    document.cookie = "user=; expires=" + fechaExpiracion + "; path=/";
    location.reload()
}

function ObtenerFloraFauna() {
    fetch('/crud/comentarioflora', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    }).then(res => {
        res.json().then(json => {
            productos = json;
            ImprimirProductos();
        });
    });
}

function ImprimirProductos() {
    let contenedor = document.getElementById("cuerpoTabla");
    contenedor.innerHTML = "";

    productos.forEach(producto => {
        contenedor.innerHTML += MapearProducto(producto);
    });
}

function MapearProducto(producto) {
    return `<tr>
    <td>
        <button class="border rounded-full bg-[#dfe7a3] w-20 h-8" onclick="EliminarFloraFauna('${producto.cod}', '${producto.comentario}')">Eliminar</button>
        <button class="border rounded-full text-white bg-[#6ea1a3] w-20 h-8" onclick="PopularDatosCampos('${producto.cod}', '${producto.comentario}')">Actualizar</button>
      </td>
    <td>${producto.cod}</td>
    <td>${producto.comentario}</td>
    <td>${producto.fecha}</td>
    <td>${producto.cod_usuario}</td>
  </tr>`;
}

function EliminarFloraFauna(cod, comment) {

    fetch('/crud/comentarioflora?cod=' + cod + '&coment=' + comment, { method: "Delete" }).then(res => {
        ObtenerFloraFauna();
    });
}


function PopularDatosCampos(cod, comment) {
    let producto = productos.filter(p => p.cod === cod && p.comentario === comment)[0];

    document.getElementById('codi').value = producto.cod;
    document.getElementById('fecha').value = producto.fecha;
    document.getElementById('cod_user').value = producto.cod_usuario;
    document.getElementById('comentario').value = producto.comentario;
    let botonactualizar = document.getElementById('actualizar')
    botonactualizar.setAttribute("onclick", "ActualizarProducto('" +producto.comentario +"')")
}

function ActualizarProducto(comment) {
    let cod = document.getElementById("codi").value;
    let comentario = document.getElementById("comentario").value;
    fetch("/crud/comentarioflora?coment="+comment, {
        method: "PUT",
        body: JSON.stringify({ cod, comentario }),
        headers: {
            "Content-type": 'application/json; charset=UTF-8'
        }
    }).then(res => {
        ObtenerFloraFauna();
    });
}
