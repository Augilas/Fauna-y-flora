async function obtenerComentarios() {
    getCookie()
    try {
        // Realizar las solicitudes fetch juntas usando Promise.all()
        const [comentariosPlantasResponse, comentariosAnimalesResponse] = await Promise.all([
            fetch('http://localhost:8080/comentarios/plantas'),
            fetch('http://localhost:8080/comentarios/animales')
        ]);

        // Verificar si hay algún error en las respuestas
        if (!comentariosPlantasResponse.ok) {
            throw new Error('Error al obtener los comentarios de plantas: ' + comentariosPlantasResponse.statusText);
        }

        if (!comentariosAnimalesResponse.ok) {
            throw new Error('Error al obtener los comentarios de animales: ' + comentariosAnimalesResponse.statusText);
        }

        // Procesar los datos de las respuestas
        const dataPlantas = await comentariosPlantasResponse.json();
        const dataAnimales = await comentariosAnimalesResponse.json();

        // Manejar los datos de las plantas
        manejarDatos(dataPlantas, 'contenedor-cartas-plantas');

        // Manejar los datos de los animales
        manejarDatos(dataAnimales, 'contenedor-cartas-animales');

    } catch (error) {
        console.error('Error:', error);
    }
}


async function manejarDatos(data, contenedorId) {
    try {
        const contenedorCartas = document.getElementById(contenedorId);
        data.forEach(function (planta) {
            const carta = document.createElement('div');
            carta.classList.add('bg-[#e6e6e6]', 'p-4', 'rounded', 'shadow', 'mb-4', 'flex', 'flex-col', 'mx-auto');

            // Contenedor para el contenido principal
            const contenido = document.createElement('div');
            contenido.classList.add('flex', 'md:flex-row', 'h-full', 'gap-10', 'flex-col');

            const contenidoInfo = document.createElement('div');
            contenidoInfo.classList.add('flex', 'flex-col', 'h-full', 'gap-2');

            // Contenedor para la imagen
            const contenedorImagen = document.createElement('div');
            contenedorImagen.classList.add('w-full', 'h-64', 'mb-2', 'rounded-t', 'flex', 'flex-col');

            // Agregar la imagen dentro del contenedor
            const imagen = document.createElement('img');
            imagen.src = 'data:image/png;base64,' + planta.base64String;
            imagen.classList.add('w-full', 'h-full', 'object-cover');

            // Agregar el popup de tippy
            if (planta.descripcionCientifica != null) {
                tippy(imagen, {
                    content: planta.descripcionCientifica,
                    placement: 'top',
                    interactive: true,
                    touch: 'hold'
                });
            }

            contenedorImagen.appendChild(imagen);
            contenidoInfo.appendChild(contenedorImagen);

            // Agregar el nombre común de la planta
            const nombreComun = document.createElement('h2');
            nombreComun.classList.add('text-lg', 'font-semibold', 'mb-2', 'px-2');
            nombreComun.textContent = 'Nombre común: ';

            const nombrePlanta = document.createElement('span');
            nombrePlanta.classList.add('text-lg', 'text-gray-600');
            nombrePlanta.textContent = planta.nombre;
            nombreComun.appendChild(nombrePlanta);
            contenidoInfo.appendChild(nombreComun);

            // Agregar el nombre científico de la planta
            const nombreCientifico = document.createElement('h2');
            nombreCientifico.classList.add('text-lg', 'font-semibold', 'mb-2', 'px-2');
            nombreCientifico.textContent = 'Nombre científico: ';

            const nombrePlantaCientifico = document.createElement('span');
            nombrePlantaCientifico.classList.add('text-lg', 'text-gray-600');
            nombrePlantaCientifico.textContent = planta.nombrecientifico;
            nombreCientifico.appendChild(nombrePlantaCientifico);
            contenidoInfo.appendChild(nombreCientifico);

            contenido.appendChild(contenidoInfo);

            // Agregar los comentarios
            const contenedorComentarios = document.createElement('div');
            contenedorComentarios.classList.add('flex', 'flex-col', 'px-2', 'gap-3');

            if (planta.comentarios) {
                const comentarios = JSON.parse(planta.comentarios);
                comentarios.forEach(function (comentario) {
                    const comentarioElemento = document.createElement('div');
                    comentarioElemento.classList.add('font-bold');
                    comentarioElemento.textContent = comentario.Nombre + ': ';

                    const contenidocomentario = document.createElement('span');
                    contenidocomentario.classList.add('font-normal');
                    contenidocomentario.textContent = comentario.Comentario;
                    comentarioElemento.appendChild(contenidocomentario);
                    contenedorComentarios.appendChild(comentarioElemento);
                });
            } else {
                const sinComentarios = document.createElement('div');
                sinComentarios.textContent = 'No hay comentarios.';
                contenedorComentarios.appendChild(sinComentarios);
            }

            // Agregar los comentarios al contenido
            contenido.appendChild(contenedorComentarios);

            // Agregar el input de texto para comentarios
            const inputComentario = document.createElement('input');
            inputComentario.setAttribute('type', 'text');
            inputComentario.setAttribute('placeholder', 'Añadir comentario...');
            inputComentario.classList.add('rounded', 'p-2', 'border', 'border-gray-300', 'focus:border-blue-500', 'focus:outline-none');

            // Agregar el botón para agregar comentarios
            const btnAgregarComentario = document.createElement('button');
            btnAgregarComentario.setAttribute('data-cod', planta.cod);
            btnAgregarComentario.textContent = 'Agregar';
            btnAgregarComentario.classList.add('bg-[#66245B]', 'text-white', 'px-4', 'py-2', 'rounded', 'ml-2', 'focus:outline-none');
            btnAgregarComentario.addEventListener('click', function () {
                const comentario = inputComentario.value.trim();
                const cod = this.getAttribute('data-cod')
                if (comentario !== '') {
                    enviarComentario(cod, comentario);
                }
            });

            const contenedorAgregarComentario = document.createElement('div');

            contenedorAgregarComentario.classList.add('flex', 'items-center', 'mt-2', 'hidden');
            var nombreCookie = "user=";
            var cookies = decodeURIComponent(document.cookie).split(';');
            for (var i = 0; i < cookies.length; i++) {
                var cookie = cookies[i].trim();
                if (cookie.indexOf(nombreCookie) === 0) {
                    cookieEncontrada = true
                    let user = cookie.substring(nombreCookie.length, cookie.length);
                    if (user === "Usuario") {
                        contenedorAgregarComentario.classList.remove('hidden');
                    } else {
                        
                    }
                }
            }

            contenedorAgregarComentario.appendChild(inputComentario);
            contenedorAgregarComentario.appendChild(btnAgregarComentario);
            contenedorComentarios.appendChild(contenedorAgregarComentario);

            // Agregar el contenido a la carta
            carta.appendChild(contenido);

            // Agregar la carta al contenedor
            contenedorCartas.appendChild(carta);
        });



    } catch (error) {
        console.error('Error:', error);
    }
}

function Salir() {
    var fechaActual = new Date();

    fechaActual.setDate(fechaActual.getDate() - 1);

    var fechaExpiracion = fechaActual.toUTCString();

    document.cookie = "token=; expires=" + fechaExpiracion + "; path=/";
    document.cookie = "user=; expires=" + fechaExpiracion + "; path=/";
    location.reload()
}

function enviarComentario(cod, comentario) {
    let valor = cod.split("-")
    let tipo = ""
    if (valor[0] == 1) {
        tipo = 'fauna'
        const tokenValue = document.cookie.split('; ')
            .find(cookie => cookie.startsWith('token'))
            ?.split('=')[1];
        fetch('/api/coment', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Cookie': tokenValue
            },
            body: JSON.stringify({ cod, comentario, tipo })
        })
            .then(res => {
                res.json().then(json => {
                    if (json == 1) {
                        swal({
                            text: "Se ha insertado correctamente el comentario",
                            icon: "success",
                        });
                    } else {
                        swal({
                            text: "Ya existe un comentario similar. Porfavor ingrese uno diferente",
                            icon: "error",
                        });
                    }
                })
            })
            .catch(error => {
                console.error('Error al enviar la solicitud:', error);
            });
    } else {
        tipo = 'flora'
        const tokenValue = document.cookie.split('; ')
            .find(cookie => cookie.startsWith('token'))
            ?.split('=')[1];
        fetch('/api/coment', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Cookie': tokenValue
            },
            body: JSON.stringify({ cod, comentario, tipo })
        })
            .then(res => {
                res.json().then(json => {
                    if (json == 1) {
                        swal({
                            text: "Se ha insertado correctamente el comentario",
                            icon: "success",
                        })
                    } else {
                        swal({
                            text: "Ya existe un comentario similar. Porfavor ingrese uno diferente",
                            icon: "error",
                        });
                    }
                })
            })
            .catch(error => {
                console.error('Error al enviar la solicitud:', error);
                swal({
                    text: "Error al procesar la respuesta del servidor",
                    icon: "error",
                });
            });
    }
}

function getCookie() {
    var nombreCookie = "user=";
    var cookies = decodeURIComponent(document.cookie).split(';');
    var cookieEncontrada = false
    for (var i = 0; i < cookies.length; i++) {
        var cookie = cookies[i].trim();
        if (cookie.indexOf(nombreCookie) === 0) {
            cookieEncontrada = true
            let user = cookie.substring(nombreCookie.length, cookie.length);
            if (user === "Biologo") {

                var navegador = document.getElementById("navegador");

                var linkBiologo = document.createElement("a");
                linkBiologo.href = "/biologo";
                linkBiologo.className = "publish-btn text-white text-2xl mb-2 lg:mb-6 flex items-center";
                linkBiologo.innerHTML = '<i class="fas fa-pencil-alt mr-2 lg:mr-4"></i><span class="hidden lg:inline">CRUD</span>';

                var linkReportes = document.createElement("a");
                linkReportes.href = "/reportes";
                linkReportes.className = "publish-btn text-white text-2xl mb-2 lg:mb-6 flex items-center";
                linkReportes.innerHTML = '<i class="fas fa-file-alt mr-2 lg:mr-4"></i><span class="hidden lg:inline">Reportes</span>';

                var linkPerfil = document.createElement("a");
                linkPerfil.href = "/perfil";
                linkPerfil.className = "text-white text-2xl mb-2 lg:mb-20 flex items-center";
                linkPerfil.innerHTML = '<i class="fas fa-user mr-2 lg:mr-4"></i><span class="hidden lg:inline">Perfil</span>';

                navegador.appendChild(linkBiologo);
                navegador.appendChild(linkReportes);
                navegador.appendChild(linkPerfil);

                var ulElement = document.createElement("ul");
                ulElement.className = "flex flex-row items-center";

                var liElement = document.createElement("li");
                liElement.className = "text-2xl cursor-pointer items-center justify-center relative group z-2 text-white mr-2 mb-3";

                var barsIcon = document.createElement("i");
                barsIcon.className = "fas fa-bars";

                liElement.appendChild(barsIcon);

                var ulInsideLi = document.createElement("ul");
                ulInsideLi.className = "hidden absolute bg-gray-700 py-2 px-4 space-y-2 text-white group-hover:block";

                var ayudaLi = document.createElement("li");
                ayudaLi.innerHTML = '<a class="style-a text-white hover:bg-black text-2xl" href="/help">Ayuda</a>';

                var salirLi = document.createElement("li");
                salirLi.innerHTML = '<a class="style-a text-white hover:bg-black text-2xl" href="">Salir</a>';
                salirLi.setAttribute("onclick", "Salir()");
                ulInsideLi.appendChild(ayudaLi);
                ulInsideLi.appendChild(salirLi);

                liElement.appendChild(ulInsideLi);

                var masLi = document.createElement("li");
                masLi.className = "text-white mb-3 text-2xl hidden lg:inline";
                masLi.textContent = "Mas";

                ulElement.appendChild(liElement);
                ulElement.appendChild(masLi);

                navegador.appendChild(ulElement);


            } else if (user === "Admin") {
                var navegador = document.getElementById("navegador");

                var linkBiologo = document.createElement("a");
                linkBiologo.href = "/admin";
                linkBiologo.className = "publish-btn text-white text-2xl mb-2 lg:mb-6 flex items-center";
                linkBiologo.innerHTML = '<i class="fas fa-pencil-alt mr-2 lg:mr-4"></i><span class="hidden lg:inline">CRUD</span>';

                var linkReportes = document.createElement("a");
                linkReportes.href = "/reportes";
                linkReportes.className = "publish-btn text-white text-2xl mb-2 lg:mb-6 flex items-center";
                linkReportes.innerHTML = '<i class="fas fa-file-alt mr-2 lg:mr-4"></i><span class="hidden lg:inline">Reportes</span>';

                var linkPerfil = document.createElement("a");
                linkPerfil.href = "/perfil";
                linkPerfil.className = "text-white text-2xl mb-2 lg:mb-20 flex items-center";
                linkPerfil.innerHTML = '<i class="fas fa-user mr-2 lg:mr-4"></i><span class="hidden lg:inline">Perfil</span>';

                navegador.appendChild(linkBiologo);
                navegador.appendChild(linkReportes);
                navegador.appendChild(linkPerfil);

                var ulElement = document.createElement("ul");
                ulElement.className = "flex flex-row items-center";

                var liElement = document.createElement("li");
                liElement.className = "text-2xl cursor-pointer items-center justify-center relative group z-2 text-white mr-2 mb-3";

                var barsIcon = document.createElement("i");
                barsIcon.className = "fas fa-bars";

                liElement.appendChild(barsIcon);

                var ulInsideLi = document.createElement("ul");
                ulInsideLi.className = "hidden absolute bg-gray-700 py-2 px-4 space-y-2 text-white group-hover:block";

                var ayudaLi = document.createElement("li");
                ayudaLi.innerHTML = '<a class="style-a text-white hover:bg-black text-2xl" href="/help">Ayuda</a>';

                var salirLi = document.createElement("li");
                salirLi.innerHTML = '<a class="style-a text-white hover:bg-black text-2xl" href="">Salir</a>';
                salirLi.setAttribute("onclick", "Salir()");
                ulInsideLi.appendChild(ayudaLi);
                ulInsideLi.appendChild(salirLi);

                liElement.appendChild(ulInsideLi);

                var masLi = document.createElement("li");
                masLi.className = "text-white mb-3 text-2xl hidden lg:inline";
                masLi.textContent = "Mas";

                ulElement.appendChild(liElement);
                ulElement.appendChild(masLi);

                navegador.appendChild(ulElement);
            } else if (user === "Usuario") {
                var navegador = document.getElementById("navegador");

                var linkPublicar = document.createElement("a");
                linkPublicar.href = "/post";
                linkPublicar.className = "publish-btn text-white text-2xl mb-2 lg:mb-6 flex items-center";
                linkPublicar.innerHTML = '<i class="fas fa-plus-circle mr-2 lg:mr-4"></i><span class="hidden lg:inline">Publicar</span>';

                var linkPerfil = document.createElement("a");
                linkPerfil.href = "/perfil";
                linkPerfil.className = "text-white text-2xl mb-2 lg:mb-20  flex items-center";
                linkPerfil.innerHTML = '<i class="fas fa-user mr-2 lg:mr-4"></i><span class="hidden lg:inline">Perfil</span>';

                navegador.appendChild(linkPublicar);
                navegador.appendChild(linkPerfil);

                var ulElement = document.createElement("ul");
                ulElement.className = "flex flex-row items-center";

                var liElement = document.createElement("li");
                liElement.className = "text-2xl cursor-pointer items-center justify-center relative group z-2 text-white mr-2 mb-3";

                var barsIcon = document.createElement("i");
                barsIcon.className = "fas fa-bars";

                liElement.appendChild(barsIcon);

                var ulInsideLi = document.createElement("ul");
                ulInsideLi.className = "hidden absolute bg-gray-700 py-2 px-4 space-y-2 text-white group-hover:block";

                var ayudaLi = document.createElement("li");
                ayudaLi.innerHTML = '<a class="style-a text-white hover:bg-black text-2xl" href="/help">Ayuda</a>';

                var salirLi = document.createElement("li");
                salirLi.innerHTML = '<a class="style-a text-white hover:bg-black text-2xl" href="">Salir</a>';
                salirLi.setAttribute("onclick", "Salir()");
                ulInsideLi.appendChild(ayudaLi);
                ulInsideLi.appendChild(salirLi);

                liElement.appendChild(ulInsideLi);

                var masLi = document.createElement("li");
                masLi.className = "text-white mb-3 text-2xl hidden lg:inline";
                masLi.textContent = "Mas";

                ulElement.appendChild(liElement);
                ulElement.appendChild(masLi);

                navegador.appendChild(ulElement);
            } else {

            }
        }
    }
    if (!cookieEncontrada) {
        console.log(cookieEncontrada)
        var navegador = document.getElementById("navegador");

        var linkPerfil = document.createElement("a");
        linkPerfil.href = "/login";
        linkPerfil.className = "text-white text-2xl mb-2 lg:mb-20 flex items-center";
        linkPerfil.innerHTML = '<i class="fas fa-user mr-2 lg:mr-4"></i><span class="hidden lg:inline">Login</span>';

        navegador.appendChild(linkPerfil);


    }
}