package com.example.semestral.Controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.semestral.Model.Crud.Admin;
import com.example.semestral.Model.Crud.Biologo;
import com.example.semestral.Model.Crud.Comentarios;
import com.example.semestral.Model.Crud.Estudiante;
import com.example.semestral.Model.Crud.FloraFauna;
import com.example.semestral.Model.Crud.Lugar;
import com.example.semestral.Model.Crud.TipoUsuario;
import com.example.semestral.Model.Crud.Usuario;
import com.example.semestral.Services.Crud;

@RestController
@RequestMapping("/crud")
public class CrudController {
    @GetMapping("/tipousuario")
    public List<TipoUsuario> ObtenerUsuarios() {
        return new Crud().GenerarTipoUsuario();
    }
    @PutMapping("/tipousuario")
    public int ActualizarUsuarios(@RequestBody TipoUsuario tipo) {
        return new Crud().ActualizarTipoUsuario(tipo);
    }
    @PostMapping("/tipousuario")
    public int NuevoUsuarios(@RequestParam String cod, @RequestParam String nombre) {
        return new Crud().NuevoTipoUsuario(cod, nombre);
    }
    @DeleteMapping("/tipousuario")
    public int BorrarUsuarios(@RequestParam Integer id) {
        return new Crud().BorrarTipoUsuario(id);
    }
    @GetMapping("/comentarioflora")
    public List<Comentarios> ObtenerComentariosFlora() {
        return new Crud().GenerarComentarioFlora();
    }
    @PutMapping("/comentarioflora")
    public int ActualizarComentariosFlora(@RequestBody Comentarios item, @RequestParam String coment) {
        return new Crud().ActualizarComentarioFlora(item, coment);
    }
    @DeleteMapping("/comentarioflora")
    public int BorrarComentariosFlora(@RequestParam String cod, @RequestParam String coment) {
        return new Crud().BorrarComentarioFlora(cod, coment);
    }
    @GetMapping("/comentariofauna")
    public List<Comentarios> ObtenerComentariosFauna() {
        return new Crud().GenerarComentarioFauna();
    }
    @PutMapping("/comentariofauna")
    public int ActualizarComentariosFauna(@RequestBody Comentarios item, @RequestParam String coment) {
        return new Crud().ActualizarComentarioFauna(item, coment);
    }
    @DeleteMapping("/comentariofauna")
    public int BorrarComentariosFauna(@RequestParam String cod, @RequestParam String coment) {
        return new Crud().BorrarComentarioFauna(cod, coment);
    }
    @GetMapping("/usuario")
    public List<Usuario> GenerarUsuarios() {
        return new Crud().GenerarUsuarios();
    }
    @DeleteMapping("/usuario")
    public int BorrarUsuarios(@RequestParam String cod) {
        return new Crud().BorrarUsuario(cod);
    }
    @PostMapping("/usuario")
    public int NuevoUsuarios(@RequestBody Usuario user) {
        return new Crud().GuardarUsuario(user);
    }
    @PutMapping("/usuario")
    public int ActualizarUsuarios(@RequestBody Usuario user) {
        return new Crud().ActualizarUsuario(user);
    }
    @GetMapping("/lugar")
    public List<Lugar> Generarlugar() {
        return new Crud().GenerarLugar();
    }
    @DeleteMapping("/lugar")
    public int Borrarlugar(@RequestParam String cod) {
        return new Crud().BorrarLugar(cod);
    }
    @PostMapping("/lugar")
    public int Nuevolugar(@RequestParam String lugar) {
        return new Crud().NuevoLugar(lugar);
    }
    @PutMapping("/lugar")
    public int Actualizarlugar(@RequestParam int cod, @RequestParam String lugar) {
        return new Crud().ActualizarLugar(cod, lugar);
    }
    @GetMapping("/estudiante")
    public List<Estudiante> GenerarEstudiante() {
        return new Crud().GenerarEstudiante();
    }
    @PostMapping("/estudiante")
    public int NuevoEstudiante(@RequestBody Estudiante est) {
        return new Crud().NuevoEstudiante(est);
    }
    @PutMapping("/estudiante")
    public int ActualizarEstudiante(@RequestBody Estudiante est) {
        return new Crud().ActualizarEstudiante(est);
    }
    @DeleteMapping("/estudiante")
    public int BorraroEstudiante(@RequestParam String cedula) {
        return new Crud().BorrarEstudiante(cedula);
    }
    @GetMapping("/biologo")
    public List<Biologo> GenerarBiologo() {
        return new Crud().GenerarBiologo();
    }
    @PutMapping("/biologo")
    public int ActualizarBiologo(@RequestBody Biologo bio) {
        return new Crud().ActualizarBiologo(bio);
    }
    @PostMapping("/biologo")
    public int NenerarBiologo(@RequestBody Biologo bio) {
        return new Crud().NuevoBiologo(bio);
    }
    @DeleteMapping("/biologo")
    public int BorrarBiologo(@RequestParam String cedula) {
        return new Crud().BorrarBiologo(cedula);
    }
    @GetMapping("/admin")
    public List<Admin> GenerarAdministrador() {
        return new Crud().GenerarAdministrador();
    }
    @PutMapping("/admin")
    public int ActualizarAdministrador(@RequestBody Admin admin) {
        return new Crud().ActualizarAdministrador(admin);
    }
    @PostMapping("/admin")
    public int NuevoAdministrador(@RequestBody Admin admin) {
        return new Crud().NuevoAdministrador(admin);
    }
    @DeleteMapping("/admin")
    public int BorraroAdministrador(@RequestParam String cedula) {
        return new Crud().BorrarAdministrador(cedula);
    }
}
