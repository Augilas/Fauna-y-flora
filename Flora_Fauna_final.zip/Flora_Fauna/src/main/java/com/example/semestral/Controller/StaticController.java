package com.example.semestral.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.example.semestral.Model.Rpassword;

import jakarta.servlet.http.HttpServletRequest;


@Controller
public class StaticController {

    @Autowired
    private RestTemplate restTemplate;

    @GetMapping("/register")
    public String Register() {
        return "Registro.html";
    }

    @GetMapping("/login")
    public String login() {
        return "Login.html";
    }

    @GetMapping("/reset_password")
    public String Contrasena() {
        return "PasswordReset.html";
    }

    @GetMapping("/change_password")
    public String ContrasenaCambio(@RequestParam(required = false) String token, HttpServletRequest request) {
        if (token != null) {
            String url = "http://"+ request.getServerName() + ":" + request.getServerPort() +"/auth/reset-password";
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
    
            Rpassword rp = new Rpassword();
            rp.setToken(token);
            HttpEntity<Rpassword> rq = new HttpEntity<>(rp, headers);
            ResponseEntity<Boolean> responseEntity = restTemplate.postForEntity(url, rq, Boolean.class);
            boolean resultado = responseEntity.getBody();
            
            if (resultado) {
                return "PasswordResetConfirm.html";
            } else {
                return "redirect:login";
            }
        } else {
            return "redirect:login";
        }
    }

    @GetMapping("/help")
    public String Ayuda() {
        return "Ayuda.html";
    }

    @GetMapping("/post")
    public String Post() {
        return "RegistrarFloraFauna.html";
    }
    @GetMapping("/")
    public String Home() {
        return "/Home.html";
    }
    @GetMapping("/perfil")
    public String Perfil() {
        return "Perfil.html";
    }
    @GetMapping("/reportes")
    public String Reportes() {
        return "Reportes.html";
    }
    public String accessDenied() {
        return "redirect:/login";
    }
    @GetMapping("/biologo")
    public String Biologo(){
        return "CRUDBiologo.html";
    }
    //CRUD
    @GetMapping("/admin")
    public String CRAdmin(){
        return "CRUD_Administrador.html";
    }
    @GetMapping("/admin_comentarios_fauna")
    public String CRAdminComentarioFauna(){
        return "CRUD_Comentarios_fauna.html";
    }
    @GetMapping("/admin_comentarios_flora")
    public String CRAdminComentarioFlora(){
        return "CRUD_Comentarios_flora.html";
    }
    @GetMapping("/admin_estudiante")
    public String CRAdminEstudiante(){
        return "CRUD_Estudiante.html";
    }
    @GetMapping("/admin_fauna")
    public String CRAdminFauna(){
        return "CRUD_Fauna.html";
    }
    @GetMapping("/admin_flora_fauna")
    public String CRAdminFloraFauna(){
        return "CRUD_Flora_fauna.html";
    }
    @GetMapping("/admin_flora")
    public String CRAdminFlora(){
        return "CRUD_Flora.html";
    }
    @GetMapping("/admin_lugar")
    public String CRAdminLugar(){
        return "CRUD_Lugar.html";
    }
    @GetMapping("/admin_tipo_usuario")
    public String CRAdminTipoUsuario(){
        return "CRUD_Tipo_usuario.html";
    }
    @GetMapping("/admin_user_biologo")
    public String CRAdminBiologo(){
        return "CRUD_user_biologo.html";
    }
    @GetMapping("/admin_usuario")
    public String CRAdminUsuario(){
        return "CRUD_Usuario.html";
    }
}
