package com.example.semestral.Model.Crud;

public class TipoUsuario {
    private String cod;
    private String tipo;
    public String getCod() {
        return cod;
    }
    public void setCod(String cod) {
        this.cod = cod;
    }
    public String getTipo() {
        return tipo;
    }
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    public TipoUsuario(String cod, String tipo) {
        this.cod = cod;
        this.tipo = tipo;
    }
}
