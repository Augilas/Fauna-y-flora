package com.example.semestral.Services;

import com.example.semestral.Model.Comentario;
import com.example.semestral.Model.Perfil;
import com.example.semestral.Model.Post;
import com.example.semestral.Model.ReportesModel;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestParam;

public class PostDB {
    private Connection _cn;

    public PostDB() {
        _cn = new Conexion().openDb();
    }

    public int GuardarPost(Post post, String user) {
        int Cod_lugar = 0;
        String cedula = "", Cod_flora = "";

        try {
            if ("flora".equals(post.getTipo())) {
                // Verifica si ya existe con ese nombre
                String VerifQuery = "SELECT COUNT(*) AS count FROM Flora WHERE Nombre_comun_flora = ?";
                PreparedStatement selectVerifPstmt = _cn.prepareStatement(VerifQuery);
                selectVerifPstmt.setString(1, post.getNombre());
                ResultSet rwws = selectVerifPstmt.executeQuery();

                boolean plantaExistente = false;

                if (rwws.next()) {
                    int count = rwws.getInt("count");
                    plantaExistente = count > 0;
                }

                rwws.close();
                selectVerifPstmt.close();

                if (!plantaExistente) {
                    String insertQuery = "INSERT INTO Flora (Nombre_comun_flora, Imagen_flora) VALUES (?, ?)";
                    PreparedStatement insertPstmt = _cn.prepareStatement(insertQuery);
                    insertPstmt.setString(1, post.getNombre());
                    insertPstmt.setBytes(2, post.getbase64String());
                    insertPstmt.executeUpdate();

                    // Segunda consulta: seleccionar Cedula_estudiante de la tabla Usuario y
                    String selectQuery = "SELECT u.Cedula_estudiante " +
                            "FROM Usuario u " +
                            "JOIN Estudiante e ON u.Cedula_estudiante = e.Cedula_estudiante " +
                            "WHERE u.Usuario = ?";
                    PreparedStatement selectPstmt = _cn.prepareStatement(selectQuery);
                    selectPstmt.setString(1, user);
                    ResultSet rs = selectPstmt.executeQuery();
                    while (rs.next()) {
                        cedula = rs.getString("Cedula_estudiante");
                    }
                    rs.close();
                    selectPstmt.close();

                    // Tercera consulta: seleccionar Cod_lugar de la tabla Lugar
                    String selectLugarQuery = "SELECT Cod_lugar FROM Lugar WHERE Nombre_lugar = ?";
                    PreparedStatement selectLugarPstmt = _cn.prepareStatement(selectLugarQuery);
                    selectLugarPstmt.setString(1, post.getLugar());
                    ResultSet lugarRs = selectLugarPstmt.executeQuery();
                    while (lugarRs.next()) {
                        Cod_lugar = lugarRs.getInt("Cod_lugar");
                    }
                    lugarRs.close();
                    selectLugarPstmt.close();

                    // Cuarta consulta: seleccionar Cod_Flora de la tabla Flora
                    String selectCodFloraQuery = "select Cod_flora from Flora where Nombre_comun_flora = ?";
                    PreparedStatement selectFloraPstmt = _cn.prepareStatement(selectCodFloraQuery);
                    selectFloraPstmt.setString(1, post.getNombre());
                    ResultSet rws = selectFloraPstmt.executeQuery();
                    while (rws.next()) {
                        Cod_flora = rws.getString("Cod_flora");
                    }
                    rws.close();
                    selectFloraPstmt.close();

                    // Quinta consulta: Ternaria
                    String insertQuery2 = "insert into Lugar_flora_estudiante (Cod_lugar_flora, Cod_flora_Lugar_flora, Cedula_estudiante_lugar_flora) values (?, ?, ?)";
                    PreparedStatement insertPstmt2 = _cn.prepareStatement(insertQuery2);
                    insertPstmt2.setInt(1, Cod_lugar);
                    insertPstmt2.setString(2, Cod_flora);
                    insertPstmt2.setString(3, cedula);
                    insertPstmt2.executeUpdate();

                    return 1;
                } else {
                    return 0;
                }
            } else {
                // Verifica si ya existe con ese nombre
                String VerifQuery = "SELECT COUNT(*) AS count FROM Fauna WHERE Nombre_comun_animal = ?";
                PreparedStatement selectVerifPstmt = _cn.prepareStatement(VerifQuery);
                selectVerifPstmt.setString(1, post.getNombre());
                ResultSet rwws = selectVerifPstmt.executeQuery();

                boolean animalExistente = false;

                if (rwws.next()) {
                    int count = rwws.getInt("count");
                    animalExistente = count > 0;
                }

                rwws.close();
                selectVerifPstmt.close();

                if (!animalExistente) {
                    String insertQuery = "INSERT INTO Fauna (Nombre_comun_animal, Imagen_animal) VALUES (?, ?)";
                    PreparedStatement insertPstmt = _cn.prepareStatement(insertQuery);
                    insertPstmt.setString(1, post.getNombre());
                    insertPstmt.setBytes(2, post.getbase64String());
                    insertPstmt.executeUpdate();

                    // Segunda consulta: seleccionar Cedula_estudiante de la tabla Usuario y
                    String selectQuery = "SELECT u.Cedula_estudiante " +
                            "FROM Usuario u " +
                            "JOIN Estudiante e ON u.Cedula_estudiante = e.Cedula_estudiante " +
                            "WHERE u.Usuario = ?";
                    PreparedStatement selectPstmt = _cn.prepareStatement(selectQuery);
                    selectPstmt.setString(1, user);
                    ResultSet rs = selectPstmt.executeQuery();
                    while (rs.next()) {
                        cedula = rs.getString("Cedula_estudiante");
                    }
                    rs.close();
                    selectPstmt.close();

                    // Tercera consulta: seleccionar Cod_lugar de la tabla Lugar
                    String selectLugarQuery = "SELECT Cod_lugar FROM Lugar WHERE Nombre_lugar = ?";
                    PreparedStatement selectLugarPstmt = _cn.prepareStatement(selectLugarQuery);
                    selectLugarPstmt.setString(1, post.getLugar());
                    ResultSet lugarRs = selectLugarPstmt.executeQuery();
                    while (lugarRs.next()) {
                        Cod_lugar = lugarRs.getInt("Cod_lugar");
                    }
                    lugarRs.close();
                    selectLugarPstmt.close();

                    // Cuarta consulta: seleccionar Cod_Flora de la tabla Flora
                    String selectCodFaunaQuery = "select Cod_animal from Fauna where Nombre_comun_animal = ?";
                    PreparedStatement selectFaunaPstmt = _cn.prepareStatement(selectCodFaunaQuery);
                    selectFaunaPstmt.setString(1, post.getNombre());
                    ResultSet rws = selectFaunaPstmt.executeQuery();
                    while (rws.next()) {
                        Cod_flora = rws.getString("Cod_animal");
                    }
                    rws.close();
                    selectFaunaPstmt.close();

                    // Quinta consulta: Ternaria
                    String insertQuery2 = "insert into Lugar_fauna_estudiante (Cod_lugar_fauna, Cod_animal_lugar_fauna, Cedula_estudiante_lugar_fauna) values (?, ?, ?)";
                    PreparedStatement insertPstmt2 = _cn.prepareStatement(insertQuery2);
                    insertPstmt2.setInt(1, Cod_lugar);
                    insertPstmt2.setString(2, Cod_flora);
                    insertPstmt2.setString(3, cedula);
                    insertPstmt2.executeUpdate();
                    return 1;
                } else {
                    return 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }

    // arreglar
    public ResponseEntity<Integer> GuardarComentario(Comentario coment, String user) {
        String cod_estudiante = "";
        try {
            // Encuentra el usuario
            String selectQuery = "select Cod_usuario from Usuario where Usuario = ?";
            PreparedStatement selectPstmt = _cn.prepareStatement(selectQuery);
            selectPstmt.setString(1, user);
            ResultSet rs = selectPstmt.executeQuery();
            while (rs.next()) {
                cod_estudiante = rs.getString("Cod_usuario");
            }
            rs.close();
            selectPstmt.close();
            if("flora".equals(coment.getTipo())) {
                String insertQuery = "insert into Comentarios_flora(Cod_flora_comentarios, Comentario_flora, Cod_usuario) values (?, ?, ?)";
                PreparedStatement insertPstmt = _cn.prepareStatement(insertQuery);
                insertPstmt.setString(1, coment.getCod());
                insertPstmt.setString(2, coment.getComentario());
                insertPstmt.setString(3, cod_estudiante);
                insertPstmt.executeUpdate();
                return ResponseEntity.ok().body(1);
            } else {
                String insertQuery = "insert into Comentarios_fauna(Cod_animal_comentarios, Comentario_animal, Cod_usuario) values (?, ?, ?)";
                PreparedStatement insertPstmt = _cn.prepareStatement(insertQuery);
                insertPstmt.setString(1, coment.getCod());
                insertPstmt.setString(2, coment.getComentario());
                insertPstmt.setString(3, cod_estudiante);
                insertPstmt.executeUpdate();
                return ResponseEntity.ok().body(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ResponseEntity.ok().body(0);
    }

    public ReportesModel Reportes(int mes, int year) {
        ReportesModel reportes = new ReportesModel();
        reportes.setCantidad_comentario_fauna(0);
        reportes.setCantidad_comentario_flora(0);
        reportes.setCantidad_post_fauna(0);
        reportes.setCantidad_post_flora(0);
        reportes.setNombre("No Existe Registro");
        try {
            String query = "SELECT COUNT(*) AS Cantidad_Post FROM Flora WHERE MONTH(Fecha_visto_primero_flora) = ? AND YEAR(Fecha_visto_primero_flora) = ?";
            PreparedStatement pstmt = _cn.prepareStatement(query);
            pstmt.setInt(1, mes);
            pstmt.setInt(2, year);
            ResultSet resultSet = pstmt.executeQuery();
            while (resultSet.next()) {
                reportes.setCantidad_post_flora(resultSet.getInt("Cantidad_Post"));
            }
            resultSet.close();
            pstmt.close();
    
            // Query 2
            String query2 = "SELECT COUNT(*) AS Cantidad_Post FROM Fauna WHERE MONTH(Fecha_visto_primero_animal) = ? AND YEAR(Fecha_visto_primero_animal) = ?";
            PreparedStatement pstmt2 = _cn.prepareStatement(query2);
            pstmt2.setInt(1, mes);
            pstmt2.setInt(2, year);
            ResultSet resultSet2 = pstmt2.executeQuery();
            while (resultSet2.next()) {
                reportes.setCantidad_post_fauna(resultSet2.getInt("Cantidad_Post"));
            }
            resultSet2.close();
            pstmt2.close();
    
            // Query 3
            String query3 = "SELECT COUNT(*) AS Cantidad_Comentario FROM Comentarios_flora WHERE MONTH(Fecha_comentario_flora) = ? AND YEAR(Fecha_comentario_flora) = ?";
            PreparedStatement pstmt3 = _cn.prepareStatement(query3);
            pstmt3.setInt(1, mes);
            pstmt3.setInt(2, year);
            ResultSet resultSet3 = pstmt3.executeQuery();
            while (resultSet3.next()) {
                reportes.setCantidad_comentario_flora(resultSet3.getInt("Cantidad_Comentario"));
            }
            resultSet3.close();
            pstmt3.close();
    
            // Query 4
            String query4 = "SELECT COUNT(*) AS Cantidad_Comentario FROM Comentarios_fauna WHERE MONTH(Fecha_comentario_fauna) = ? AND YEAR(Fecha_comentario_fauna) = ?";
            PreparedStatement pstmt4 = _cn.prepareStatement(query4);
            pstmt4.setInt(1, mes);
            pstmt4.setInt(2, year);
            ResultSet resultSet4 = pstmt4.executeQuery();
            while (resultSet4.next()) {
                reportes.setCantidad_comentario_fauna(resultSet4.getInt("Cantidad_Comentario"));
            }
            resultSet4.close();
            pstmt4.close();
    
            // Query 5
            String sql = "{CALL ObtenerCodigoConMasComentarios(?, ?, ?)}";
            CallableStatement stmt = _cn.prepareCall(sql);
            stmt.setInt(1, mes);
            stmt.setInt(2, year);
            stmt.registerOutParameter(3, Types.VARCHAR);
            stmt.execute();
            reportes.setNombre(stmt.getString(3));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return reportes;
    }    
}
