package com.example.semestral.Model.Crud;

public class Usuario {
    private String cod;
    private String usuario;
    private String contrasena;
    private String fecha;
    private String cedulaestudiante;
    private String cedulabiologo;
    private String cedulaadmin;
    private int codtipo;
    public String getCod() {
        return cod;
    }
    public void setCod(String cod) {
        this.cod = cod;
    }
    public String getUsuario() {
        return usuario;
    }
    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }
    public String getContrasena() {
        return contrasena;
    }
    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }
    public String getFecha() {
        return fecha;
    }
    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    public String getCedulaestudiante() {
        return cedulaestudiante;
    }
    public void setCedulaestudiante(String cedulaestudiante) {
        this.cedulaestudiante = cedulaestudiante;
    }
    public String getCedulabiologo() {
        return cedulabiologo;
    }
    public void setCedulabiologo(String cedulabiologo) {
        this.cedulabiologo = cedulabiologo;
    }
    public String getCedulaadmin() {
        return cedulaadmin;
    }
    public void setCedulaadmin(String cedulaadmin) {
        this.cedulaadmin = cedulaadmin;
    }
    public int getCodtipo() {
        return codtipo;
    }
    public void setCodtipo(int codtipo) {
        this.codtipo = codtipo;
    }
    public Usuario(String cod, String usuario, String contrasena, String fecha, String cedulaestudiante,
            String cedulabiologo, String cedulaadmin, int codtipo) {
        this.cod = cod;
        this.usuario = usuario;
        this.contrasena = contrasena;
        this.fecha = fecha;
        this.cedulaestudiante = cedulaestudiante;
        this.cedulabiologo = cedulabiologo;
        this.cedulaadmin = cedulaadmin;
        this.codtipo = codtipo;
    }
}
