package com.example.semestral.Config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.example.semestral.Auth.JWTAuthorizationFilter;

@EnableWebSecurity
@Configuration
class SecurityConf {

        @Autowired
        JWTAuthorizationFilter jwtAuthorizationFilter;

        @Bean
        public SecurityFilterChain configure(HttpSecurity http) throws Exception {

                http
                                .csrf(AbstractHttpConfigurer::disable)
                                .authorizeHttpRequests(request -> request
                                                .requestMatchers(HttpMethod.POST, "/auth/**").permitAll()
                                                .requestMatchers(HttpMethod.POST, "/api/perfil").authenticated()
                                                .requestMatchers("/perfil", "/Perfil.html").authenticated()
                                                .requestMatchers("/img/**", "/css/**", "/js/**", "/Registro.html",
                                                                "/Login.html", "/PasswordReset.html", "/Ayuda.html",
                                                                "/Home.html")
                                                .permitAll()
                                                .requestMatchers("/login", "/register", "/reset_password", "/help", "/",
                                                                "comentarios/**", "/florafauna/all", "/florafauna", "/crud/**")
                                                .permitAll()
                                                .requestMatchers("/admin",
                                                                "/admin_comentarios_fauna",
                                                                "/admin_comentarios_flora",
                                                                "/admin_estudiante",
                                                                "/admin_fauna",
                                                                "/admin_flora_fauna",
                                                                "/admin_flora",
                                                                "/admin_lugar",
                                                                "/admin_tipo_usuario",
                                                                "/admin_user_biologo",
                                                                "/admin_usuario",
                                                                "/CRUD_Administrador.html",
                                                                "/CRUD_Comentarios_fauna.html",
                                                                "/CRUD_Comentarios_flora.html",
                                                                "/CRUD_Estudiante.html",
                                                                "/CRUD_Fauna.html",
                                                                "/CRUD_Flora_fauna.html",
                                                                "/CRUD_Flora.html",
                                                                "/CRUD_Lugar.html",
                                                                "/CRUD_Tipo_usuario.html",
                                                                "/CRUD_user_biologo.html",
                                                                "/CRUD_Usuario.html")
                                                .hasAuthority("Administrador")
                                                .requestMatchers("CRUDBiologo.html", "/biologo")
                                                .hasAuthority("Biologo")
                                                .requestMatchers("api/reportes", "/Reportes.html", "/reportes")
                                                .hasAnyAuthority("Administrador", "Biologo")
                                                .requestMatchers("/RegistrarFloraFauna.html", "/post", "/api/post")
                                                .authenticated()
                                                .requestMatchers("/change_password", "/PasswordResetConfirm.html")
                                                .permitAll()
                                                .anyRequest()
                                                .authenticated())
                                .addFilterAfter(jwtAuthorizationFilter, UsernamePasswordAuthenticationFilter.class)
                                .exceptionHandling().accessDeniedHandler(accessDeniedHandler());
                return http.build();
        }

        @Bean
        public AccessDeniedHandler accessDeniedHandler() {
                return new CustomAccessDeniedHandler();
        }
}
