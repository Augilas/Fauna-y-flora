package com.example.semestral.Model.Crud;

public class FloraFauna {
    private String cod;
    private String nombre;
    private String nombrecientifico;
    private byte[] imagen;
    private String fecha;
    private String descripcion;
    public FloraFauna(String cod, String nombre, String nombrecientifico, byte[] imagen, String fecha,
            String descripcion) {
        this.cod = cod;
        this.nombre = nombre;
        this.nombrecientifico = nombrecientifico;
        this.imagen = imagen;
        this.fecha = fecha;
        this.descripcion = descripcion;
    }
    public String getCod() {
        return cod;
    }
    public void setCod(String cod) {
        this.cod = cod;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getNombrecientifico() {
        return nombrecientifico;
    }
    public void setNombrecientifico(String nombrecientifico) {
        this.nombrecientifico = nombrecientifico;
    }
    public byte[] getImagen() {
        return imagen;
    }
    public void setImagen(byte[] imagen) {
        this.imagen = imagen;
    }
    public String getFecha() {
        return fecha;
    }
    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    public String getDescripcion() {
        return descripcion;
    }
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
