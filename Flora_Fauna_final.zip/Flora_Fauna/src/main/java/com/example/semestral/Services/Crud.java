package com.example.semestral.Services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.security.crypto.bcrypt.BCrypt;

import com.example.semestral.Model.Register;
import com.example.semestral.Model.Crud.Admin;
import com.example.semestral.Model.Crud.Biologo;
import com.example.semestral.Model.Crud.Comentarios;
import com.example.semestral.Model.Crud.Estudiante;
import com.example.semestral.Model.Crud.FloraFauna;
import com.example.semestral.Model.Crud.Lugar;
import com.example.semestral.Model.Crud.TipoUsuario;
import com.example.semestral.Model.Crud.Usuario;

public class Crud {
    private final String hashsalt = "$2a$10$asdsamlsacpwpewieqwmlqwñ";

    private Connection _cn;

    public Crud() {
        _cn = new Conexion().openDb();
    }

    public List<FloraFauna> ObtenerFloraFauna(String tipo) {
        try {
            if ("1".equals(tipo)) {
                Statement stmt = _cn.createStatement();
                String query = "select * from Fauna";

                List<FloraFauna> items = new ArrayList<>();
                ResultSet result = stmt.executeQuery(query);
                while (result.next()) {
                    FloraFauna item = new FloraFauna(
                            result.getString("Cod_animal"),
                            result.getString("Nombre_comun_animal"),
                            result.getString("Nombre_cientifico_animal"),
                            result.getBytes("Imagen_animal"),
                            result.getString("Fecha_visto_primero_animal"),
                            result.getString("Descripcion_cientifica_fauna"));

                    items.add(item);
                }

                result.close();
                stmt.close();
                return items;
            } else {
                Statement stmt = _cn.createStatement();
                String query = "select * from Flora";

                List<FloraFauna> items = new ArrayList<>();
                ResultSet result = stmt.executeQuery(query);
                while (result.next()) {
                    FloraFauna item = new FloraFauna(
                            result.getString("Cod_flora"),
                            result.getString("Nombre_comun_flora"),
                            result.getString("Nombre_cientifico_flora"),
                            result.getBytes("Imagen_flora"),
                            result.getString("Fecha_visto_primero_flora"),
                            result.getString("Descripcion_cientifica_flora"));

                    items.add(item);
                }

                result.close();
                stmt.close();
                return items;
            }

        } catch (Exception e) {
            int x = 1;
        }
        return null;
    }

    public int ActualizarFloraFauna(FloraFauna item, String tipo) {
        int resultado = 0;
        try {
            if ("1".equals(tipo)) {
                String query = "UPDATE Fauna SET ";

                if (item.getNombre() != null) {
                    query += "Nombre_comun_animal = ?, ";
                }

                if (item.getNombrecientifico() != null) {
                    query += "Nombre_cientifico_animal = ?, ";

                }

                if (item.getDescripcion() != null) {
                    query += "Descripcion_cientifica_fauna = ?, ";
                }

                if (item.getImagen() != null) {
                    query += "Imagen_animal = ?, ";
                }

                if (item.getFecha() != null) {
                    query += "Fecha_visto_primero_animal = ?, ";
                }

                query = query.substring(0, query.length() - 2) + " WHERE Cod_animal = ?";
                PreparedStatement stm = _cn.prepareStatement(query);

                int index = 1;

                if (item.getNombre() != null) {
                    stm.setString(index++, item.getNombre());
                }

                if (item.getNombrecientifico() != null) {
                    stm.setString(index++, item.getNombrecientifico());
                }

                if (item.getDescripcion() != null) {
                    stm.setString(index++, item.getDescripcion());
                }

                if (item.getImagen() != null) {
                    stm.setBytes(index++, item.getImagen());
                }

                if (item.getFecha() != null) {
                    stm.setString(index++, item.getFecha());
                }

                stm.setString(index, item.getCod());

                resultado = stm.executeUpdate();

                return resultado;
            } else {
                String query = "UPDATE Flora SET ";

                if (item.getNombre() != null) {
                    query += "Nombre_comun_flora = ?, ";
                }

                if (item.getNombrecientifico() != null) {
                    query += "Nombre_cientifico_flora = ?, ";
                }

                if (item.getDescripcion() != null) {
                    query += "Descripcion_cientifica_flora = ?, ";
                }

                if (item.getImagen() != null) {
                    query += "Imagen_flora = ?, ";
                }

                if (item.getFecha() != null) {
                    query += "Fecha_visto_primero_flora = ?, ";
                }

                query = query.substring(0, query.length() - 2) + " WHERE Cod_flora = ?";
                PreparedStatement stm = _cn.prepareStatement(query);
                int index = 1;

                if (item.getNombre() != null) {
                    stm.setString(index++, item.getNombre());
                }

                if (item.getNombrecientifico() != null) {
                    stm.setString(index++, item.getNombrecientifico());
                }

                if (item.getDescripcion() != null) {
                    stm.setString(index++, item.getDescripcion());
                }

                if (item.getImagen() != null) {
                    stm.setBytes(index++, item.getImagen());
                }

                if (item.getFecha() != null) {
                    stm.setString(index++, item.getFecha());
                }

                stm.setString(index, item.getCod());

                resultado = stm.executeUpdate();

                return resultado;
            }
        } catch (Exception e) {
            int x = 1;
        }
        return resultado;
    }

    public int EliminarFloraFauna(String code, String tipo) {
        int resultado = 0;
        try {
            if ("1".equals(tipo)) {
                String query = "delete from Fauna where Cod_animal = ?";
                PreparedStatement stm = _cn.prepareStatement(query);
                stm.setString(1, code);
                resultado = stm.executeUpdate();

                return resultado;
            } else {
                String query = "delete from Flora where Cod_flora = ?";
                PreparedStatement stm = _cn.prepareStatement(query);
                stm.setString(1, code);
                resultado = stm.executeUpdate();
                return resultado;
            }
        } catch (Exception e) {
            int x = 1;
        }
        return resultado;
    }

    // Crud Tipo usuario
    public List<TipoUsuario> GenerarTipoUsuario() {
        try {
            Statement stmt = _cn.createStatement();
            String query = "select * from Tipo_usuario";

            List<TipoUsuario> items = new ArrayList<>();
            ResultSet result = stmt.executeQuery(query);
            while (result.next()) {
                TipoUsuario item = new TipoUsuario(
                        result.getString("cod_tipo"),
                        result.getString("Tipo"));
                items.add(item);
            }

            result.close();
            stmt.close();
            return items;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public int ActualizarTipoUsuario(TipoUsuario tipo) {
        int resultado = 0;
        try {
            System.out.println(tipo.getCod());
            String query = "update Tipo_usuario set Tipo = ? where cod_tipo = ?";
            PreparedStatement stm = _cn.prepareStatement(query);
            stm.setString(1, tipo.getTipo());
            stm.setString(2, tipo.getCod());
            resultado = stm.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultado;
    }

    public int BorrarTipoUsuario(Integer id) {
        int resultado = 0;
        try {
            String query = "delete from Tipo_usuario where cod_tipo = ?";
            PreparedStatement stm = _cn.prepareStatement(query);
            stm.setInt(1, id);
            resultado = stm.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultado;
    }

    public int NuevoTipoUsuario(String id, String nombre) {
        int resultado = 0;
        try {
            String query = "insert into Tipo_usuario(cod_tipo, Tipo) values (?, ?)";
            PreparedStatement stm = _cn.prepareStatement(query);
            stm.setString(1, id);
            stm.setString(2, nombre);
            resultado = stm.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return resultado;
        }
        return resultado;
    }

    // CRUD COMENTARIOS
    public List<Comentarios> GenerarComentarioFlora() {
        try {
            Statement stmt = _cn.createStatement();
            String query = "select * from Comentarios_flora";

            List<Comentarios> items = new ArrayList<>();
            ResultSet result = stmt.executeQuery(query);
            while (result.next()) {
                Comentarios item = new Comentarios(
                        result.getString("Cod_flora_comentarios"),
                        result.getString("Comentario_flora"),
                        result.getString("Fecha_comentario_flora"),
                        result.getString("Cod_usuario"));
                items.add(item);
            }

            result.close();
            stmt.close();
            return items;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public int ActualizarComentarioFlora(Comentarios item, String coment) {
        int resultado = 0;
        try {
            String query = "update Comentarios_flora set Comentario_flora = ? where Comentario_flora = ? and Cod_flora_comentarios = ?";
            PreparedStatement stm = _cn.prepareStatement(query);
            stm.setString(1, item.getComentario());
            stm.setString(2, coment);
            stm.setString(3, item.getCod());
            resultado = stm.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultado;
    }

    public int BorrarComentarioFlora(String cod, String coment) {
        int resultado = 0;
        try {
            String query = "delete from Comentarios_flora where Cod_flora_comentarios = ? and Comentario_flora = ?";
            PreparedStatement stm = _cn.prepareStatement(query);
            stm.setString(1, cod);
            stm.setString(2, coment);
            resultado = stm.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultado;
    }

    public List<Comentarios> GenerarComentarioFauna() {
        try {
            Statement stmt = _cn.createStatement();
            String query = "select * from Comentarios_fauna";

            List<Comentarios> items = new ArrayList<>();
            ResultSet result = stmt.executeQuery(query);
            while (result.next()) {
                Comentarios item = new Comentarios(
                        result.getString("Cod_animal_comentarios"),
                        result.getString("Comentario_animal"),
                        result.getString("Fecha_comentario_fauna"),
                        result.getString("Cod_usuario"));
                items.add(item);
            }

            result.close();
            stmt.close();
            return items;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public int ActualizarComentarioFauna(Comentarios item, String coment) {
        int resultado = 0;
        try {
            String query = "update Comentarios_fauna set Comentario_animal = ? where Comentario_animal = ? and Cod_animal_comentarios = ?";
            PreparedStatement stm = _cn.prepareStatement(query);
            stm.setString(1, item.getComentario());
            stm.setString(2, coment);
            stm.setString(3, item.getCod());
            resultado = stm.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultado;
    }

    public int BorrarComentarioFauna(String cod, String coment) {
        int resultado = 0;
        try {
            String query = "delete from Comentarios_fauna where Cod_animal_comentarios = ? and Comentario_animal = ?";
            PreparedStatement stm = _cn.prepareStatement(query);
            stm.setString(1, cod);
            stm.setString(2, coment);
            resultado = stm.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultado;
    }

    // CRUD Usuario
    public List<Usuario> GenerarUsuarios() {
        try {
            Statement stmt = _cn.createStatement();
            String query = "select * from Usuario";

            List<Usuario> items = new ArrayList<>();
            ResultSet result = stmt.executeQuery(query);
            while (result.next()) {
                Usuario item = new Usuario(
                        result.getString("Cod_usuario"),
                        result.getString("Usuario"),
                        result.getString("Contrasena"),
                        result.getString("Creado"),
                        result.getString("Cedula_estudiante"),
                        result.getString("Cedula_biologo"),
                        result.getString("Cedula_admin"),
                        result.getInt("cod_tipo"));
                items.add(item);
            }

            result.close();
            stmt.close();
            return items;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public int BorrarUsuario(String cod) {
        int resultado = 0;
        try {
            String query = "delete from Usuario where Cod_usuario = ?";
            PreparedStatement stm = _cn.prepareStatement(query);
            stm.setString(1, cod);
            resultado = stm.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultado;
    }

    public int GuardarUsuario(Usuario user) {
        int resultado = 0;
        try {
            CallableStatement cstmt = _cn.prepareCall("{call InsertarUsuarioNuevo(?, ?, ?, ?)}");
            cstmt.setInt(1, user.getCodtipo());
            if (user.getCedulaadmin() != null) {
                cstmt.setString(2, user.getCedulaadmin());
            } else if (user.getCedulabiologo() != null) {
                cstmt.setString(2, user.getCedulabiologo());
            } else {
                cstmt.setString(2, user.getUsuario());
            }
            cstmt.setString(3, user.getUsuario());
            cstmt.setString(4, BCrypt.hashpw(user.getContrasena(), hashsalt));
            resultado = cstmt.executeUpdate();
            cstmt.close();
            System.out.println(resultado);
            return resultado;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return resultado;
    }

    public int ActualizarUsuario(Usuario user) {
        int resultado = 0;
        try {
            String query = "UPDATE Usuario SET ";

            if (user.getUsuario() != null) {
                query += "Usuario = ?, ";
            }

            if (user.getContrasena() != null) {
                query += "Contrasena = ?, ";

            }

            if (user.getCedulabiologo() != null) {
                query += "Cedula_biologo = ?, ";
            }

            if (user.getCedulaadmin() != null) {
                query += "Cedula_admin = ?, ";
            }

            if (user.getCedulaestudiante() != null) {
                query += "Cedula_estudiante = ?, ";
            }

            if (user.getCodtipo() != 0) {
                query += "cod_tipo = ?, ";
            }

            query = query.substring(0, query.length() - 2) + " WHERE Cod_usuario = ?";
            PreparedStatement stm = _cn.prepareStatement(query);

            int index = 1;

            if (user.getUsuario() != null) {
                stm.setString(index++, user.getUsuario());
            }

            if (user.getContrasena() != null) {
                stm.setString(index++, BCrypt.hashpw(user.getContrasena(), hashsalt));
            }

            if (user.getCedulabiologo() != null) {
                stm.setString(index++, user.getCedulabiologo());
            }

            if (user.getCedulaadmin() != null) {
                stm.setString(index++, user.getCedulaadmin());
            }

            if (user.getCedulaestudiante() != null) {
                stm.setString(index++, user.getCedulaestudiante());
            }

            if (user.getCodtipo() != 0) {
                stm.setInt(index++, user.getCodtipo());
            }

            stm.setString(index, user.getCod());

            resultado = stm.executeUpdate();

            return resultado;
        } catch (Exception e) {
            return resultado;
        }
    }

    // CRUD Lugar
    public List<Lugar> GenerarLugar() {
        try {
            Statement stmt = _cn.createStatement();
            String query = "select * from lugar";

            List<Lugar> items = new ArrayList<>();
            ResultSet result = stmt.executeQuery(query);
            while (result.next()) {
                Lugar item = new Lugar(
                        result.getInt("Cod_lugar"),
                        result.getString("Nombre_lugar"));
                items.add(item);
            }

            result.close();
            stmt.close();
            return items;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public int ActualizarLugar(int cod, String lugar) {
        int resultado = 0;
        try {
            String query = "update lugar set Nombre_lugar = ? where Cod_lugar = ?";
            PreparedStatement stm = _cn.prepareStatement(query);
            stm.setString(1, lugar);
            stm.setInt(2, cod);
            resultado = stm.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultado;
    }

    public int NuevoLugar(String lugar) {
        int resultado = 0;
        try {
            String query = "insert into Lugar values (?)";
            PreparedStatement stm = _cn.prepareStatement(query);
            stm.setString(1, lugar);
            resultado = stm.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultado;
    }

    public int BorrarLugar(String cod) {
        int resultado = 0;
        try {
            String query = "delete from lugar where Cod_lugar = ?";
            PreparedStatement stm = _cn.prepareStatement(query);
            stm.setString(1, cod);
            resultado = stm.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultado;
    }

    // CRUD ESTUDIANTE
    public List<Estudiante> GenerarEstudiante() {
        try {
            Statement stmt = _cn.createStatement();
            String query = "select * from estudiante";

            List<Estudiante> items = new ArrayList<>();
            ResultSet result = stmt.executeQuery(query);
            while (result.next()) {
                Estudiante item = new Estudiante(
                        result.getString("Cedula_estudiante"),
                        result.getString("Nombre_estudiante"),
                        result.getString("Apellido_estudiante"),
                        result.getString("Telefono_estudiante"),
                        result.getString("Correo_estudiante"),
                        result.getInt("cod_tipo"));
                items.add(item);
            }

            result.close();
            stmt.close();
            return items;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public int NuevoEstudiante(Estudiante user) {
        int resultado = 0;
        try {
            String query = "insert into Estudiante (Cedula_estudiante, Nombre_estudiante, Apellido_estudiante, Telefono_estudiante, Correo_estudiante, cod_tipo) values (?, ?, ?, ?, ?, ?)";
            PreparedStatement stm = _cn.prepareStatement(query);
            stm.setString(1, user.getCedula());
            stm.setString(2, user.getNombre());
            stm.setString(3, user.getApellido());
            stm.setString(4, user.getTelefono());
            stm.setString(5, user.getCorreo());
            stm.setInt(6, user.getCodtipo());
            resultado = stm.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(user.getTelefono());
        }
        return resultado;
    }

    public int ActualizarEstudiante(Estudiante user) {
        int resultado = 0;
        try {
            String query = "UPDATE Estudiante SET ";

            if (user.getNombre() != null) {
                query += "Nombre_estudiante = ?, ";
            }

            if (user.getApellido() != null) {
                query += "Apellido_estudiante = ?, ";

            }

            if (user.getCorreo() != null) {
                query += "Correo_estudiante = ?, ";
            }

            if (user.getTelefono() != null) {
                query += "Telefono_estudiante = ?, ";
            }

            if (user.getCodtipo() != 0) {
                query += "cod_tipo = ?, ";
            }

            query = query.substring(0, query.length() - 2) + " WHERE Cedula_estudiante = ?";
            PreparedStatement stm = _cn.prepareStatement(query);

            int index = 1;

            if (user.getNombre() != null) {
                stm.setString(index++, user.getNombre());
            }

            if (user.getApellido() != null) {
                stm.setString(index++, user.getApellido());
            }

            if (user.getCorreo() != null) {
                stm.setString(index++, user.getCorreo());
            }

            if (user.getTelefono() != null) {
                stm.setString(index++, user.getTelefono());
            }

            if (user.getCodtipo() != 0) {
                stm.setInt(index++, user.getCodtipo());
            }

            stm.setString(index, user.getCedula());

            resultado = stm.executeUpdate();

            return resultado;
        } catch (Exception e) {
            return resultado;
        }
    }

    public int BorrarEstudiante(String cedula) {
        int resultado = 0;
        try {
            String query = "delete from Estudiante where Cedula_estudiante = ?";
            PreparedStatement stm = _cn.prepareStatement(query);
            stm.setString(1, cedula);
            resultado = stm.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultado;
    }

    // CRUD Biologo
    public List<Biologo> GenerarBiologo() {
        try {
            Statement stmt = _cn.createStatement();
            String query = "select * from Biologo";

            List<Biologo> items = new ArrayList<>();
            ResultSet result = stmt.executeQuery(query);
            while (result.next()) {
                Biologo item = new Biologo(
                        result.getString("Cedula_biologo"),
                        result.getString("Nombre_biologo"),
                        result.getString("Apellido_biologo"),
                        result.getString("Telefono_biologo"),
                        result.getString("Correo_biologo"),
                        result.getInt("cod_tipo"),
                        result.getInt("verificado"));
                items.add(item);
            }

            result.close();
            stmt.close();
            return items;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public int NuevoBiologo(Biologo user) {
        int resultado = 0;
        try {
            String query = "insert into Biologo (Cedula_biologo, Nombre_biologo, Apellido_biologo, Telefono_biologo, Correo_biologo, cod_tipo, verificado) values (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement stm = _cn.prepareStatement(query);
            stm.setString(1, user.getCedula());
            stm.setString(2, user.getNombre());
            stm.setString(3, user.getApellido());
            stm.setString(4, user.getTelefono());
            stm.setString(5, user.getCorreo());
            stm.setInt(6, user.getCodtipo());
            stm.setInt(7, user.getVerificado());
            resultado = stm.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(user.getTelefono());
        }
        return resultado;
    }

    public int ActualizarBiologo(Biologo user) {
        int resultado = 0;
        try {
            String query = "UPDATE biologo SET ";

            if (user.getNombre() != null) {
                query += "Nombre_biologo = ?, ";
            }

            if (user.getApellido() != null) {
                query += "Apellido_biologo = ?, ";

            }

            if (user.getCorreo() != null) {
                query += "Correo_biologo = ?, ";
            }

            if (user.getTelefono() != null) {
                query += "Telefono_biologo = ?, ";
            }

            if (user.getCodtipo() != 0) {
                query += "cod_tipo = ?, ";
            }

            if (user.getVerificado() == 0 || user.getVerificado() == 1) {
                query += "verificado = ?, ";
            }

            query = query.substring(0, query.length() - 2) + " WHERE Cedula_biologo = ?";
            PreparedStatement stm = _cn.prepareStatement(query);

            int index = 1;

            if (user.getNombre() != null) {
                stm.setString(index++, user.getNombre());
            }

            if (user.getApellido() != null) {
                stm.setString(index++, user.getApellido());
            }

            if (user.getCorreo() != null) {
                stm.setString(index++, user.getCorreo());
            }

            if (user.getTelefono() != null) {
                stm.setString(index++, user.getTelefono());
            }

            if (user.getCodtipo() != 0) {
                stm.setInt(index++, user.getCodtipo());
            }

            if (user.getVerificado() == 0 || user.getVerificado() == 1) {
                stm.setInt(index++, user.getVerificado());
            }

            stm.setString(index, user.getCedula());

            resultado = stm.executeUpdate();

            return resultado;
        } catch (Exception e) {
            return resultado;
        }
    }

    public int BorrarBiologo(String cedula) {
        int resultado = 0;
        try {
            String query = "delete from Biologo where Cedula_biologo = ?";
            PreparedStatement stm = _cn.prepareStatement(query);
            stm.setString(1, cedula);
            resultado = stm.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultado;
    }

    // CRUD Administrador
    public List<Admin> GenerarAdministrador() {
        try {
            Statement stmt = _cn.createStatement();
            String query = "select * from Administrador";

            List<Admin> items = new ArrayList<>();
            ResultSet result = stmt.executeQuery(query);
            while (result.next()) {
                Admin item = new Admin(
                        result.getString("Cedula_admin"),
                        result.getString("Nombre_admin"),
                        result.getString("Apellido_admin"),
                        result.getString("Correo_admin"),
                        result.getInt("cod_tipo"));
                items.add(item);
            }

            result.close();
            stmt.close();
            return items;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public int NuevoAdministrador(Admin user) {
        int resultado = 0;
        try {
            String query = "insert into Administrador (Cedula_admin, Nombre_admin, Apellido_admin, Correo_admin, cod_tipo) values (?, ?, ?, ?, ?)";
            PreparedStatement stm = _cn.prepareStatement(query);
            stm.setString(1, user.getCedula());
            stm.setString(2, user.getNombre());
            stm.setString(3, user.getApellido());
            stm.setString(4, user.getCorreo());
            stm.setInt(5, user.getCodtipo());
            resultado = stm.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultado;
    }

    public int ActualizarAdministrador(Admin user) {
        int resultado = 0;
        try {
            String query = "UPDATE Administrador SET ";

            if (user.getNombre() != null) {
                query += "Nombre_admin = ?, ";
            }

            if (user.getApellido() != null) {
                query += "Apellido_admin = ?, ";

            }

            if (user.getCorreo() != null) {
                query += "Correo_admin = ?, ";
            }

            if (user.getCodtipo() != 0) {
                query += "cod_tipo = ?, ";
            }

            query = query.substring(0, query.length() - 2) + " WHERE Cedula_admin = ?";
            PreparedStatement stm = _cn.prepareStatement(query);

            int index = 1;

            if (user.getNombre() != null) {
                stm.setString(index++, user.getNombre());
            }

            if (user.getApellido() != null) {
                stm.setString(index++, user.getApellido());
            }

            if (user.getCorreo() != null) {
                stm.setString(index++, user.getCorreo());
            }

            if (user.getCodtipo() != 0) {
                stm.setInt(index++, user.getCodtipo());
            }

            stm.setString(index, user.getCedula());

            resultado = stm.executeUpdate();

            return resultado;
        } catch (Exception e) {
            return resultado;
        }
    }

    public int BorrarAdministrador(String cedula) {
        int resultado = 0;
        try {
            String query = "delete from Administrador where Cedula_admin = ?";
            PreparedStatement stm = _cn.prepareStatement(query);
            stm.setString(1, cedula);
            resultado = stm.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultado;
    }
}
