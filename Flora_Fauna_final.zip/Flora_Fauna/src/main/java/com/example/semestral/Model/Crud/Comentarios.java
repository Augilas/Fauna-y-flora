package com.example.semestral.Model.Crud;

public class Comentarios {
    private String cod;
    private String comentario;
    private String fecha;
    private String cod_usuario;
    public String getCod() {
        return cod;
    }
    public void setCod(String cod) {
        this.cod = cod;
    }
    public String getComentario() {
        return comentario;
    }
    public void setComentario(String comentario) {
        this.comentario = comentario;
    }
    public String getFecha() {
        return fecha;
    }
    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    public String getCod_usuario() {
        return cod_usuario;
    }
    public void setCod_usuario(String cod_usuario) {
        this.cod_usuario = cod_usuario;
    }
    public Comentarios(String cod, String comentario, String fecha, String cod_usuario) {
        this.cod = cod;
        this.comentario = comentario;
        this.fecha = fecha;
        this.cod_usuario = cod_usuario;
    }
}
