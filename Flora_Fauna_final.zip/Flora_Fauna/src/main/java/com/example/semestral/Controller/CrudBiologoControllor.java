package com.example.semestral.Controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.semestral.Model.Crud.FloraFauna;
import com.example.semestral.Services.Crud;

@RestController
public class CrudBiologoControllor {
    @GetMapping("/florafauna/all")
    public List<FloraFauna> ObtenerTodos(@RequestParam String id) {
        return new Crud().ObtenerFloraFauna(id);
    }
    @PutMapping("/florafauna")
    public int ActualizarFloraFauna(@RequestBody FloraFauna item, @RequestParam String tipo) {
        return new Crud().ActualizarFloraFauna(item, tipo);
    }
    @DeleteMapping("/florafauna")
    public int EliminarFloraFauna(@RequestParam String cod, @RequestParam String tipo) {
        return new Crud().EliminarFloraFauna(cod, tipo);
    }
}
