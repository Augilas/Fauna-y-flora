package com.example.semestral.Controller;

import com.example.semestral.Model.Perfil;
import com.example.semestral.Model.Post;
import com.example.semestral.Model.ReportesModel;
import com.example.semestral.Services.PerfilDB;
import com.example.semestral.Services.PostDB;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;

import static com.example.semestral.Auth.Constans.SUPER_SECRET_KEY;
import static com.example.semestral.Auth.Constans.getSigningKey;

import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class PerfilController {
    @PostMapping("/perfil")
    public List<com.example.semestral.Model.Perfil> Perfil(HttpServletRequest request) {
        String token = Arrays.stream(request.getCookies())
                .filter(cookie -> "token".equals(cookie.getName()))
                .map(Cookie::getValue)
                .findAny()
                .orElse(null);
        if (token != null) {
            Claims claims = Jwts.parser()
                    .setSigningKey(getSigningKey(SUPER_SECRET_KEY))
                    .parseClaimsJws(token)
                    .getBody();
            String sub = claims.getSubject();

            List<String> authorities = (List<String>) claims.get("authorities"); 

            if (authorities != null && !authorities.isEmpty()) {
                return new PerfilDB().obtenerPerfil(sub, authorities.get(0));
            }
        } else {
            return null;
        }
        return null;
    }
    @PostMapping("/reportes")
    public ReportesModel Reportes(@RequestParam int mes, @RequestParam int year) {
        return new PostDB().Reportes(mes, year);
    }
    @PostMapping("/actualizar")
    public int ActualizarPerfil(@RequestBody Perfil user) {
        return new PerfilDB().EditarPerfil(user);
    }
}
