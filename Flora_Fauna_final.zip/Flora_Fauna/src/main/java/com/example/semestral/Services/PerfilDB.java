package com.example.semestral.Services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.example.semestral.Model.Perfil;

public class PerfilDB {
    private Connection _cn;

    public PerfilDB() {
        _cn = new Conexion().openDb();
    }

    public List<Perfil> obtenerPerfil(String sub, String authority) {
        List<Perfil> perf = new ArrayList<>();
        try {
            if ("Usuario".equals(authority)) {
                String query = "select e.Nombre_estudiante as Nombre, e.Apellido_estudiante as Apellido, e.Cedula_estudiante as Cedula, e.Correo_estudiante as Correo, e.Telefono_estudiante as Telefono from Estudiante e join Usuario u on e.Cedula_estudiante = u.Cedula_estudiante where u.Usuario = ?";
                PreparedStatement pstmt = _cn.prepareStatement(query);
                pstmt.setString(1, sub);
                ResultSet resultSet = pstmt.executeQuery();
                while (resultSet.next()) {
                    String nombre = resultSet.getString("Nombre");
                    String appelido = resultSet.getString("Apellido");
                    String cedula = resultSet.getString("Cedula");
                    String correo = resultSet.getString("Correo");
                    String telefono = resultSet.getString("Telefono");
                    int verificado = -1;
                    Perfil perfi = new Perfil();
                    perfi.setNombre(nombre);
                    perfi.setVerificado(verificado);
                    perfi.setApellido(appelido);
                    perfi.setCedula(cedula);
                    perfi.setCorreo(correo);
                    perfi.setTelefono(telefono);
                    perf.add(perfi);
                }
                resultSet.close();
                pstmt.close();
                return perf;
            } else if ("Biologo".equals(authority)) {
                String query = "select b.Nombre_biologo as Nombre, b.Apellido_biologo as Apellido, b.Cedula_biologo as Cedula, b.Correo_biologo as Correo, b.Telefono_biologo as Telefono, b.verificado as verificado from Biologo b join Usuario u on b.Cedula_biologo = u.Cedula_biologo where u.Usuario = ?";
                PreparedStatement pstmt = _cn.prepareStatement(query);
                pstmt.setString(1, sub);
                ResultSet resultSet = pstmt.executeQuery();
                while (resultSet.next()) {
                    String nombre = resultSet.getString("Nombre");
                    String appelido = resultSet.getString("Apellido");
                    String cedula = resultSet.getString("Cedula");
                    String correo = resultSet.getString("Correo");
                    String telefono = resultSet.getString("Telefono");
                    int verificado = resultSet.getInt("verificado");
                    Perfil perfi = new Perfil();
                    perfi.setNombre(nombre);
                    perfi.setApellido(appelido);
                    perfi.setCedula(cedula);
                    perfi.setCorreo(correo);
                    perfi.setVerificado(verificado);
                    perfi.setTelefono(telefono);
                    perf.add(perfi);
                }
                resultSet.close();
                pstmt.close();
                return perf;
            } else {
                String query = "select a.Nombre_admin as Nombre, a.Apellido_admin as Apellido, a.Cedula_admin as Cedula, a.Correo_admin as Correo from Administrador a join Usuario u on a.Cedula_admin = u.Cedula_admin where u.Usuario = ?";
                PreparedStatement pstmt = _cn.prepareStatement(query);
                pstmt.setString(1, sub);
                ResultSet resultSet = pstmt.executeQuery();
                while (resultSet.next()) {
                    String nombre = resultSet.getString("Nombre");
                    String appelido = resultSet.getString("Apellido");
                    String cedula = resultSet.getString("Cedula");
                    String correo = resultSet.getString("Correo");
                    int verificado = -1;
                    Perfil perfi = new Perfil();
                    perfi.setNombre(nombre);
                    perfi.setVerificado(verificado);
                    perfi.setApellido(appelido);
                    perfi.setCedula(cedula);
                    perfi.setCorreo(correo);
                    perf.add(perfi);
                }
                resultSet.close();
                pstmt.close();
                return perf;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return perf;
    }

    public int EditarPerfil(Perfil user) {
        int resultado = 0;
        try {
            if ("Usuario".equals(user.getTipo())) {
                String query = "UPDATE Estudiante SET ";
    
                if (user.getNombre() != "") {
                    query += "Nombre_estudiante = ?, ";
                }
    
                if (user.getApellido() != "") {
                    query += "Apellido_estudiante = ?, ";
                }
    
                if (user.getCorreo() != "") {
                    query += "Correo_estudiante = ?, ";
                }
    
                if (user.getTelefono() != "") {
                    query += "Telefono_estudiante = ?, ";
                }
    
                query = query.substring(0, query.length() - 2) + " WHERE Cedula_estudiante = ?";
                PreparedStatement stm = _cn.prepareStatement(query);
    
                int index = 1;
    
                if (user.getNombre() != "") {
                    stm.setString(index++, user.getNombre());
                }
    
                if (user.getApellido() != "") {
                    stm.setString(index++, user.getApellido());
                }
    
                if (user.getCorreo() != "") {
                    stm.setString(index++, user.getCorreo());
                }
    
                if (user.getTelefono() != "") {
                    stm.setString(index++, user.getTelefono());
                }

                stm.setString(index, user.getCedula());
    
                resultado = stm.executeUpdate();
            } else if ("Admin".equals(user.getTipo())) {
                String query = "UPDATE Administrador SET ";
    
                if (user.getNombre() != "") {
                    query += "Nombre_admin = ?, ";
                }
    
                if (user.getApellido() != "") {
                    query += "Apellido_admin = ?, ";
                }
    
                if (user.getCorreo() != "") {
                    query += "Correo_admin = ?, ";
                }
    
                query = query.substring(0, query.length() - 2) + " WHERE Cedula_admin = ?";
                PreparedStatement stm = _cn.prepareStatement(query);
    
                int index = 1;
    
                if (user.getNombre() != "") {
                    stm.setString(index++, user.getNombre());
                }
    
                if (user.getApellido() != "") {
                    stm.setString(index++, user.getApellido());
                }
    
                if (user.getCorreo() != "") {
                    stm.setString(index++, user.getCorreo());
                }
    
                stm.setString(index, user.getCedula());
    
                resultado = stm.executeUpdate();
            } else {
                String query = "UPDATE biologo SET ";
    
                if (user.getNombre() != "") {
                    query += "Nombre_biologo = ?, ";
                }
    
                if (user.getApellido() != "") {
                    query += "Apellido_biologo = ?, ";
                }
    
                if (user.getCorreo() != "") {
                    query += "Correo_biologo = ?, ";
                }
    
                if (user.getTelefono() != "") {
                    query += "Telefono_biologo = ?, ";
                }
    
    
                query = query.substring(0, query.length() - 2) + " WHERE Cedula_biologo = ?";
                PreparedStatement stm = _cn.prepareStatement(query);
    
                int index = 1;
    
                if (user.getNombre() != "") {
                    stm.setString(index++, user.getNombre());
                }
    
                if (user.getApellido() != "") {
                    stm.setString(index++, user.getApellido());
                }
    
                if (user.getCorreo() != "") {
                    stm.setString(index++, user.getCorreo());
                }
    
                if (user.getTelefono() != "") {
                    stm.setString(index++, user.getTelefono());
                }

                stm.setString(index, user.getCedula());
    
                resultado = stm.executeUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultado;
    }
    
}
