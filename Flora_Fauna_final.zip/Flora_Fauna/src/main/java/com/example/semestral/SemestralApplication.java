package com.example.semestral;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SemestralApplication {

	public static void main(String[] args) {
		SpringApplication.run(SemestralApplication.class, args);
	}

}
