package com.example.semestral.Model;

public class ReportesModel {

    private int cantidad_post_flora;
    private int cantidad_post_fauna;
    private int cantidad_comentario_flora;
    private int cantidad_comentario_fauna;
    private String Nombre;

    public int getCantidad_post_flora() {
        return cantidad_post_flora;
    }
    public void setCantidad_post_flora(int cantidad_post_flora) {
        this.cantidad_post_flora = cantidad_post_flora;
    }
    public int getCantidad_post_fauna() {
        return cantidad_post_fauna;
    }
    public void setCantidad_post_fauna(int cantidad_post_fauna) {
        this.cantidad_post_fauna = cantidad_post_fauna;
    }
    public int getCantidad_comentario_flora() {
        return cantidad_comentario_flora;
    }
    public void setCantidad_comentario_flora(int cantidad_comentario_flora) {
        this.cantidad_comentario_flora = cantidad_comentario_flora;
    }
    public int getCantidad_comentario_fauna() {
        return cantidad_comentario_fauna;
    }
    public void setCantidad_comentario_fauna(int cantidad_comentario_fauna) {
        this.cantidad_comentario_fauna = cantidad_comentario_fauna;
    }
    public String getNombre() {
        return Nombre;
    }
    public void setNombre(String nombre) {
        Nombre = nombre;
    }
}
