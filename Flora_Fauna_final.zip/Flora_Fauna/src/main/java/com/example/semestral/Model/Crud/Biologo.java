package com.example.semestral.Model.Crud;

public class Biologo {
    private String cedula;
    private String nombre;
    private String apellido;
    private String telefono;
    private String correo;
    private int codtipo;
    private int verificado;
    public Biologo(String cedula, String nombre, String apellido, String telefono, String correo, int codtipo,
            int verificado) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.apellido = apellido;
        this.telefono = telefono;
        this.correo = correo;
        this.codtipo = codtipo;
        this.verificado = verificado;
    }
    public int getVerificado() {
        return verificado;
    }
    public void setVerificado(int verificado) {
        this.verificado = verificado;
    }
    public String getCedula() {
        return cedula;
    }
    public void setCedula(String cedula) {
        this.cedula = cedula;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getApellido() {
        return apellido;
    }
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }
    public String getTelefono() {
        return telefono;
    }
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
    public String getCorreo() {
        return correo;
    }
    public void setCorreo(String correo) {
        this.correo = correo;
    }
    public int getCodtipo() {
        return codtipo;
    }
    public void setCodtipo(int codtipo) {
        this.codtipo = codtipo;
    }

}
